import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {scoreFixed, getForm} from '../integration/fixed.mjs';
import {scoreCandidate} from '../website/scoring.mjs';
import {scoreDeployed} from '../provenance/deployed-scoring-excerpt.mjs';

const vectors = JSON.parse(readFileSync(process.argv[2], 'utf8'));
let comparisons = 0;
for (const vector of vectors) {
  for (const locale of ['zh-CN', 'en']) {
    const actual = scoreFixed(vector.answers, vector.stage, locale);
    assert.deepEqual(actual, vector.expected[locale], `${vector.id}: Python/JavaScript ${locale}`);
    assert.deepEqual(actual.result, scoreCandidate(vector.answers, vector.stage));
    assert.deepEqual(actual.result, scoreDeployed(vector.answers, vector.stage), `${vector.id}: recorded deployment`);
    comparisons++;
  }
}
let invalidCount = 0;
for (const locale of ['zh-CN', 'en']) {
  for (const answers of [[], Array(16), Array(16).fill(undefined), Array(16).fill(true),
    Array(16).fill('3'), Array(16).fill(3.1), Array(16).fill(0), Array(16).fill(6), {}, null]) {
    assert.throws(() => scoreFixed(answers, 'basic', locale), {code:'E_ANSWERS'});
    invalidCount++;
  }
  assert.throws(() => scoreFixed(Array(16).fill(3), 'other', locale), {code:'E_STAGE'});
  for (const stage of ['basic', 'full']) {
    const form = getForm(stage, locale);
    assert.equal(form.items.length, stage === 'basic' ? 16 : 48);
    assert.equal(form.response_options.length, 6);
    form.items[0].text = 'caller mutation';
    assert.notEqual(getForm(stage, locale).items[0].text, 'caller mutation');
  }
}
assert.throws(() => getForm('full', 'fr'), {code:'E_LOCALE'});
assert.deepEqual(scoreFixed(Array(16).fill(3.0), 'basic'), scoreFixed(Array(16).fill(3), 'basic'));
console.log(JSON.stringify({cross_runtime_and_deployment_comparisons:comparisons, invalid_answer_checks:invalidCount,
  locale_stage_and_copy_isolation_checks:'passed', node_version:process.version}));
