import json
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'integration'))
from fixed import score_fixed, IntegrationError

locale = sys.argv[3] if len(sys.argv) > 3 else 'zh-CN'
try:
    if len(sys.argv) not in (3, 4):
        raise IntegrationError('E_USAGE', locale)
    try:
        answers = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'),
                             parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    except (OSError, ValueError):
        raise IntegrationError('E_FILE', locale) from None
    print(json.dumps(score_fixed(answers, sys.argv[2], locale), ensure_ascii=False, indent=2))
except IntegrationError as error:
    print(json.dumps({'code': error.code, 'message': str(error)}, ensure_ascii=False), file=sys.stderr)
    sys.exit(2)
