import {readFileSync} from 'node:fs';
import {scoreFixed, IntegrationError} from '../integration/fixed.mjs';

const [file, stage, locale = 'zh-CN'] = process.argv.slice(2);
try {
  if (!file || !stage || process.argv.length > 5) throw new IntegrationError('E_USAGE', locale);
  let answers;
  try { answers = JSON.parse(readFileSync(file, 'utf8')); }
  catch { throw new IntegrationError('E_FILE', locale); }
  console.log(JSON.stringify(scoreFixed(answers, stage, locale), null, 2));
} catch (error) {
  console.error(JSON.stringify({code:error.code ?? 'E_CONFIG', message:error.message}));
  process.exitCode = 2;
}
