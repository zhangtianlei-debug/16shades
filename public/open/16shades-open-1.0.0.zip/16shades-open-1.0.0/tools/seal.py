#!/usr/bin/env python3
"""Seal a prepared public release: deterministic manifest and ZIP. Does not publish."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,required=True)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output == ROOT or ROOT in output.parents:
        raise ValueError('Archive output must be outside the candidate directory')
    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts
                   and p.name not in ('.DS_Store','release-manifest.json'))
    if any(p.is_symlink() for p in ROOT.rglob('*') if '.git' not in p.parts):
        raise ValueError('Symlinks cannot be sealed')
    evidence = json.loads((ROOT/'provenance/source-evidence.json').read_text(encoding='utf-8'))
    manifest = {'schema':'16shades-open-release-manifest-1','version':'1.0.0',
                'status':'public-release-prepared','date':'2026-09-22','license_decision':'approved_mit_and_cc_by_4_0',
                'website_version':evidence['website_version'],'bank_digest':evidence['bank_digest'],
                'form_id':evidence['form_id'],'languages':['zh-CN','en'],
                'excludes':['official artwork and brand assets','personal data','credentials','runtime dependencies','working files'],
                'files':{p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files},
                'licenses':{'code':'MIT','framework_item_bank_docs_translations':'CC-BY-4.0'},
                'note':'SHA-256 checks bytes; it is not a signature or psychometric certification. This manifest excludes itself.'}
    blob = (json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
    path = ROOT/'release-manifest.json'
    if path.exists() and path.read_bytes() != blob:
        raise ValueError('A different manifest already exists. Use a new rc version for a sealed candidate.')
    path.write_bytes(blob)
    files.append(path)
    output.mkdir(parents=True,exist_ok=True)
    archive = output/'16shades-open-1.0.0.zip'
    import io
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for file in sorted(files):
            member = '16shades-open-1.0.0/' + file.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(member,date_time=(2026,9,14,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            zf.writestr(info,file.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    content = buffer.getvalue()
    if archive.exists() and archive.read_bytes() != content:
        raise ValueError('A different sealed archive already exists; use a new candidate version.')
    archive.write_bytes(content)
    digest = hashlib.sha256(content).hexdigest()
    checksum = archive.with_suffix('.zip.sha256')
    checksum.write_text(digest+'  '+archive.name+'\n',encoding='ascii')
    print(json.dumps({'archive':str(archive),'sha256':digest,'bytes':len(content),'files':len(files)},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
