import {scoreCandidate, candidateForm} from '../website/scoring.mjs';
import zh from '../website/locale.zh-CN.json' with {type:'json'};
import en from '../website/locale.en.json' with {type:'json'};
import messages from './messages.json' with {type:'json'};

export class IntegrationError extends Error {
  constructor(code, locale = 'en') {
    super(messages[locale]?.[code] ?? messages.en[code]);
    this.code = code;
  }
}

function validateStage(stage, locale) {
  if (locale !== 'zh-CN' && locale !== 'en') throw new IntegrationError('E_LOCALE');
  if (stage !== 'basic' && stage !== 'full') throw new IntegrationError('E_STAGE', locale);
}

export function getForm(stage = 'full', locale = 'zh-CN') {
  validateStage(stage, locale);
  const presentation = locale === 'en' ? en : zh;
  if (presentation.form_id !== candidateForm.form_id || presentation.bank_digest !== candidateForm.bank_digest)
    throw new IntegrationError('E_CONFIG', locale);
  return structuredClone({
    ...presentation, stage,
    items: presentation.items.slice(0, stage === 'basic' ? 16 : 48),
  });
}

export function scoreFixed(answers, stage = 'full', locale = 'zh-CN') {
  validateStage(stage, locale);
  const count = stage === 'basic' ? 16 : 48;
  if (!Array.isArray(answers) || answers.length !== count ||
      Array.from(answers).some(x => x !== null && (!Number.isInteger(x) || x < 1 || x > 5)))
    throw new IntegrationError('E_ANSWERS', locale);
  const presentation = getForm(stage, locale);
  let result;
  try { result = scoreCandidate(answers, stage); }
  catch { throw new IntegrationError('E_CONFIG', locale); }
  return {
    schema: '16shadows-integration-result-1', package_version: '1.0.0',
    presentation_locale: locale, presentation_version: presentation.version,
    language_equivalence_validated: false, heuristic_unvalidated: true,
    notice: messages[locale].notice, result,
    labels: {axes: presentation.axes, types: presentation.types},
  };
}
