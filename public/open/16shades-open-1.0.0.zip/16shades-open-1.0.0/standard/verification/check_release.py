#!/usr/bin/env python3
"""Independent release checks. Synthetic answers are not psychometric evidence."""
import json
import math
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reference"))
import shadows

AXES = ("G", "M", "H", "N")
FACETS = {
    "G": ("tradeoff", "delegation", "allocation"),
    "M": ("channel", "leverage", "resistance"),
    "H": ("closure", "recognition", "persistence"),
    "N": ("justification", "audience", "challenge"),
}
MIN_CONTEXTS = {
    "resource_conflict": 4, "authority_asymmetry": 4, "rules": 4,
    "private_relationship": 4, "strangers": 4, "competition": 4,
    "retaliation": 4, "anonymous": 2, "public": 4,
    "high_stakes": 2, "low_stakes": 8, "weaker_other": 2,
    "stronger_other": 2, "sanction_risk": 2, "low_sanction_risk": 2,
}
FIXED = [a + n for n in ("01", "17", "30", "02") for a in AXES]


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def check_form(form, by):
    ids = form["ordered_ids"]
    require(len(ids) == len(set(ids)) == 48, "48 unique items")
    require(ids[:16] == FIXED, "fixed prefix")
    rows = [by[i] for i in ids]
    for a in AXES:
        ar = [x for x in rows if x["axis"] == a]
        require(len(ar) == 12, "12 per axis")
        for facet in FACETS[a]:
            for sign in (-1, 1):
                require(sum(x["facet"] == facet and x["direction"] == sign for x in ar) == 2,
                        "two per axis/facet/direction")
        require(len({c for x in ar for c in x["contexts"]}) >= 4, "axis context coverage")
    counts = Counter(c for x in rows for c in x["contexts"])
    require(all(counts[c] >= n for c, n in MIN_CONTEXTS.items()), "global context quota")
    for i, x in enumerate(rows):
        require(not x["extreme"] and x["expected_discrimination"] != "low", "eligibility")
        require(not set(x["excludes"]) & set(ids), "excluded pair")
        if i:
            require(rows[i-1]["axis"] != x["axis"], "adjacent axis")
        for j in range(i + 1, len(rows)):
            if x["family"] == rows[j]["family"]:
                require({x["id"], rows[j]["id"]} == {x["axis"] + "01", x["axis"] + "02"},
                        "only check pair may share family")
                require(j - i >= 8, "family spacing")
    return dict(sorted(counts.items()))


def main():
    bank = shadows.load(ROOT / "bank/items.json")
    by = shadows.items_of(bank)
    require(len(by) == 160, "160 bank items")
    for a in AXES:
        rows = [x for x in by.values() if x["axis"] == a]
        require(len(rows) == 40, "40 bank items per axis")
        require(Counter(x["direction"] for x in rows) == {-1: 20, 1: 20}, "20 per pole")
        require([sum(x["facet"] == f for x in rows) for f in FACETS[a]] == [16, 12, 12],
                "bank facet blueprint")
    require(all(x["primary_weight"] == 1 for x in by.values()), "default equal weights")
    require(all(x["empirical_discrimination"] is None for x in by.values()), "no fake calibration")
    require(all((ROOT.parent / p).exists() for p in bank["source_documents"]), "source paths")
    readable = (ROOT / "F_候选母题库_160题.md").read_text(encoding="utf-8")
    require(all(x["text"] in readable for x in by.values()), "F matches bank text")

    default = shadows.load(ROOT / "default_form.json")
    require(default == shadows.select(bank, "reference-zh-CN-1"), "default replay")
    shadows.validate_form(bank, default)
    default_counts = check_form(default, by)
    public = (ROOT / "G_默认48题_公开试测稿.md").read_text(encoding="utf-8")
    require(all(by[i]["text"] in public for i in default["ordered_ids"]), "G matches default")
    require(default["form_id"] in public and default["bank_digest"] in public, "G identities")

    attempts, form_ids, exposures = [], set(), Counter()
    for n in range(100):
        seed = f"qa-{n:03d}"
        form = shadows.select(bank, seed)
        check_form(form, by)
        require(form == shadows.select(bank, seed), "seed replay")
        attempts.append(form["attempt"])
        form_ids.add(form["form_id"])
        exposures.update(form["ordered_ids"])
    require(len(form_ids) == 100, "100 distinct forms in this deterministic check")

    fixtures = shadows.load(ROOT / "verification/golden_cases.json")
    require(fixtures["bank_digest"] == default["bank_digest"], "fixture bank identity")
    require(fixtures["form_id"] == default["form_id"], "fixture form identity")
    for case in fixtures["cases"]:
        result = shadows.score(bank, default, case["answers"], case["stage"])
        e = case["expected"]
        for a in AXES:
            actual = result["axes"][a]
            score = e["scores"][a]
            require(actual["score"] is None if score is None else
                    math.isclose(actual["score"], score, abs_tol=fixtures["tolerance"], rel_tol=0),
                    case["id"] + " score " + a)
            require(actual["percent"] == e["percent"][a], case["id"] + " percent " + a)
            require(actual["direction_confidence"]["heuristic_unvalidated"] is True, "confidence label")
            if score is None:
                require(actual["direction"] is None and actual["boundary"] is None, "invalid official axis")
            if "boundary" in e:
                require(actual["boundary"] == e["boundary"], "boundary flag")
            if "confidence_level" in e:
                require(actual["direction_confidence"]["level"] == e["confidence_level"], "basic confidence")
        primary = result["type"]["primary"]
        require((None if primary is None else primary["id"]) == e["primary"], case["id"] + " primary")
        require(len(result["type"]["candidates"]) == e["candidate_count"], "candidate count")
        if "candidate_ids" in e:
            require([x["id"] for x in result["type"]["candidates"]] == e["candidate_ids"], "candidate IDs")
        if "flat_response" in e:
            require(result["flat_response"] == e["flat_response"], "flat response flag")
        require("answers" not in result and result["secondary_scoring_enabled"] is False, "no raw answers")
        if case["id"] in ("all_agree", "all_disagree"):
            value = 1 if case["id"] == "all_agree" else -1
            require(all(result["axes"][a]["pole_means"] == {"positive": value, "negative": value}
                        for a in AXES), "preserve both pole means")
            require(all(result["axes"][a]["direction_confidence"]["pair_tensions"] for a in AXES),
                    "soft pair tension observed without punishment")

    unused = sorted(set(by) - set(exposures))
    report = {
        "status": "passed",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Engineering and editorial-structure checks only; not psychometric validation.",
        "bank_digest": default["bank_digest"], "default_form_id": default["form_id"],
        "bank_items": 160, "default_items": 48, "basic_items": 16,
        "synthetic_golden_cases": len(fixtures["cases"]),
        "sampling": {
            "seed_range": "qa-000 through qa-099", "attempts_are_zero_based": True,
            "success": 100, "failure": 0, "unique_forms": len(form_ids),
            "attempt_min": min(attempts), "attempt_max": max(attempts),
            "attempt_mean": statistics.mean(attempts), "attempt_median": statistics.median(attempts),
            "not_sampled_in_this_check": unused,
        },
        "default_context_counts": default_counts,
        "checks": [
            "all bank axes, facets, directions, weights, source paths",
            "all F/G question texts match canonical bank and default manifest",
            "100 independently checked blueprints, context quotas, exclusions and spacing",
            "100 seed replays and distinct form identities",
            "24 hand-specified numeric/type/neutral/missing/basic golden cases",
            "unvalidated confidence labels, distinct pole means, no raw answers in result",
        ],
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

