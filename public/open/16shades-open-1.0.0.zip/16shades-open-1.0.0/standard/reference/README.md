# 参考实现：抽题与计分

仅Python 3标准库；当前仅支持包内1.0.0-draft.1的中文self参考配置。没有数据库、网络服务、登录、付费或第三方数据采集。它是可移植算法样例，不是已上线的网站。

在本包根目录运行：

```sh
python3 reference/shadows.py select --bank bank/items.json --seed reference-zh-CN-1
python3 reference/shadows.py score --bank bank/items.json --form default_form.json --answers verification/example_answers.json --stage full
python3 -m unittest discover -s reference -p 'test_*.py' -v
python3 verification/check_release.py
```

example_answers.json为人工构造的演示答案，不是用户数据。输出应与verification/example_result.json一致。实际网站应在会话内构造答案对象，避免写入持久日志。

## 输入

answers为题号到整数1—5或null的JSON对象；缺答必须明确null。

full需完整48个题号。basic可只提交前16个题号，也可提交48个但后32题不计分。拒绝未知/缺失/重复键、布尔值、非整数、越界值和不匹配表单。

select可用--out指定一个新表单输出文件；不要对已有用户文件使用该选项。默认只输出JSON。输入错误或配额无法满足时退出码2，成功为0。

## 行为边界

- bank是题目与权重的唯一来源；form必须能由相同bank、seed和抽题规则重放。自行重签摘要不能绕过题序和配额契约。
- 基础16固定，全48满足每轴、facet、方向、情境、互斥和family间距规则。
- 固定检查对允许共享family，但不允许在excludes中互相排斥。
- 算术以十进制权重对应的精确有理数计算；先判断零点/边界，再转JSON数值。显示百分比用half-up，62.5→63。
- score=(正方向题加权z均值−负方向题加权z均值)/2，z=(回答−3)/2。
- pole_means保留两端观测均值，防止把“两边都高”和“两边都低”的0分混为一种心理状态。
- 次维默认不计分。把握等级明确标为heuristic_unvalidated，不是概率。
- type.primary在四轴有效且非零时按符号给出；边界轴仍扩展候选，零点/不足不伪造唯一结果。
- 输出含精确版本、profile、form_id、bank_digest和实际参与题号，不含逐题答案或身份信息。
- implementation_version由代码报告，不要求修改母库来跟随实现补丁版本。

## 摘要规则

bank_digest对整个母库canonical JSON取SHA-256：UTF-8、键排序、中文不转义、无多余空格、保留数组顺序。当前发布文件的JSON数值表达是约定的一部分。

form_id对以下对象按相同规则取摘要：

```json
{"bank_digest":"...","sampling_version":"16shadows-sampling-1","ordered_ids":["..."]}
```

完整算法、门槛与版本规则分别见C、D、E。扩充题库/新语言/新profile需要显式新版本适配，当前参考程序不会静默猜测未知配置的含义。

## 测试分工

test_shadows.py覆盖错误输入、真实母库生成、计分边界、权重、缺答、固定题冲突和命令行失败等。

verification/check_release.py以独立写出的配额检查100个种子，并核对24个手工指定期望值的完整输入样例，以及F/G题面与母库一致性。全部是工程符合性检查，不是统计校准或真实用户研究。
