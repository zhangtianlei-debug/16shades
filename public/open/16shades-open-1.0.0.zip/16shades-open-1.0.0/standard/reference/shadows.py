#!/usr/bin/env python3
"""Small, deterministic reference implementation; stdlib only."""
import argparse, hashlib, json, re, sys
from fractions import Fraction
from collections import Counter, defaultdict

SAMPLING_VERSION = "16shadows-sampling-1"
SCORE_PROFILE = "open-reference-continuous-1"
IMPLEMENTATION_VERSION="1.0.0-draft.1"
BANK_IDENTITY = {"schema_version":"16shadows-bank-1","framework_version":"1.0.0-draft.1","scoring_version":"1.0.0-draft.1","item_bank_version":"1.0.0-draft.1","reference_test_version":"1.0.0-draft.1","language":"zh-CN","form_mode":"self","score_profile":SCORE_PROFILE}
AXES = "GMHN"
FACETS = {"G": ("tradeoff", "delegation", "allocation"), "M": ("channel", "leverage", "resistance"), "H": ("closure", "recognition", "persistence"), "N": ("justification", "audience", "challenge")}
QUOTAS = {"resource_conflict":4,"authority_asymmetry":4,"rules":4,"private_relationship":4,"strangers":4,"competition":4,"retaliation":4,"anonymous":2,"public":4,"high_stakes":2,"low_stakes":8,"weaker_other":2,"stronger_other":2,"sanction_risk":2,"low_sanction_risk":2}
NAMES = ["掮客","投机客","笑面客","追猎者","收割者","掠夺者","清算者","悍客","操盘手","煽动家","权术家","教主","铁腕者","定局者","裁决者","暴君"]

class ReferenceError(ValueError): pass
def canon(x): return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False)
def digest(x): return hashlib.sha256(canon(x).encode()).hexdigest()
def load(path):
    def reject_constant(v): raise ReferenceError(f"JSON 不允许非有限常量: {v}")
    def reject_duplicates(pairs):
      d={}
      for k,v in pairs:
        if k in d: raise ReferenceError(f"JSON 含重复键: {k}")
        d[k]=v
      return d
    with open(path, encoding="utf-8") as f: return json.load(f, object_pairs_hook=reject_duplicates, parse_constant=reject_constant)
def items_of(bank):
    if not isinstance(bank,dict): raise ReferenceError("bank 须为对象")
    if {k:bank.get(k) for k in BANK_IDENTITY} != BANK_IDENTITY: raise ReferenceError("bank 顶层版本身份不受当前参考实现支持")
    xs = bank.get("items")
    if not isinstance(xs,list): raise ReferenceError("bank.items 必须是数组")
    if any(not isinstance(x,dict) for x in xs): raise ReferenceError("item 须为对象")
    ids=[x.get("id") for x in xs]
    if any(not isinstance(i,str) for i in ids): raise ReferenceError("item id 须为字符串")
    if len(ids)!=len(set(ids)): raise ReferenceError("题库含重复 id")
    allowed_contexts=set(QUOTAS)
    for x in xs:
      required={"id","axis","facet","direction","text","format","contexts","mechanism","family","excludes","consistency_pair","consistency_relation","expected_discrimination","expected_basis","empirical_discrimination","primary_weight","secondary","extreme","reverse_worded","provenance","status","confound_risks","evidence_role"}
      if not required <= set(x): raise ReferenceError("item 缺少必需字段: "+str(sorted(required-set(x))))
      iid=x.get("id")
      if not isinstance(iid,str) or not re.fullmatch(r"[GMHN](?:0[1-9]|[1-9][0-9]+)",iid): raise ReferenceError(f"非法题号: {iid!r}")
      a=iid[0]
      if x.get("axis")!=a or x.get("facet") not in FACETS[a]: raise ReferenceError(f"{iid}: axis/facet 非法")
      if type(x.get("direction")) is not int or x["direction"] not in (-1,1): raise ReferenceError(f"{iid}: direction 必须为 -1 或 1")
      if x.get("format") != "agreement5": raise ReferenceError(f"{iid}: format 必须为 agreement5")
      cs=x.get("contexts")
      if not isinstance(cs,list) or not cs or any(not isinstance(c,str) or c not in allowed_contexts for c in cs): raise ReferenceError(f"{iid}: contexts 含未知或为空")
      if not 2<=len(cs)<=5 or len(set(cs))!=len(cs) or {"high_stakes","low_stakes"}<=set(cs): raise ReferenceError(f"{iid}: contexts 数量/重复/高低风险组合非法")
      for field in ("text","mechanism","expected_basis","provenance"):
        if not isinstance(x.get(field),str) or not x[field].strip(): raise ReferenceError(f"{iid}: {field} 必须为非空字符串")
      if not isinstance(x.get("family"),str) or not x["family"]: raise ReferenceError(f"{iid}: family 非法")
      if not isinstance(x.get("excludes",[]),list) or any(not isinstance(v,str) for v in x.get("excludes",[])): raise ReferenceError(f"{iid}: excludes 非法")
      if x.get("consistency_pair") is not None and not isinstance(x.get("consistency_pair"),str): raise ReferenceError(f"{iid}: consistency_pair 非法")
      if x.get("expected_discrimination") not in ("high","medium","low"): raise ReferenceError(f"{iid}: expected_discrimination 非法")
      if type(x.get("primary_weight")) not in (int,float) or not .5<=x["primary_weight"]<=1.5: raise ReferenceError(f"{iid}: primary_weight 必须是有限 [0.5,1.5] 数值")
      if x.get("empirical_discrimination") is not None or x.get("status")!="candidate_unvalidated" or x.get("evidence_role") not in ("proxy","conditional_strategy") or type(x.get("reverse_worded")) is not bool or type(x.get("extreme",False)) is not bool or not isinstance(x.get("secondary",[]),list) or not isinstance(x.get("confound_risks"),list) or any(not isinstance(v,str) for v in x["confound_risks"]): raise ReferenceError(f"{iid}: 审计字段非法")
      for sec in x.get("secondary",[]):
        if not isinstance(sec,dict) or not isinstance(sec.get("axis"),str) or sec.get("axis") not in tuple(AXES) or sec.get("axis")==a or type(sec.get("direction")) is not int or sec.get("direction") not in (-1,1) or type(sec.get("proposed_weight")) not in (int,float) or sec.get("proposed_weight") != .2 or not isinstance(sec.get("rationale"),str) or not sec["rationale"].strip(): raise ReferenceError(f"{iid}: secondary 项非法")
      if len({s["axis"] for s in x["secondary"]}) != len(x["secondary"]): raise ReferenceError(f"{iid}: secondary 重复轴")
      if x["consistency_pair"] is None and x["consistency_relation"] is not None: raise ReferenceError(f"{iid}: 非配对题不应有 consistency_relation")
    byid={x["id"]:x for x in xs}
    for x in xs:
      if x["id"] in x["excludes"] or any(v not in byid or x["id"] not in byid[v].get("excludes",[]) for v in x["excludes"]): raise ReferenceError(f"{x['id']}: excludes 必须存在且对称")
    for a in AXES:
      pair=[byid.get(a+"01"),byid.get(a+"02")]
      if None in pair or pair[0]["family"]!=pair[1]["family"] or any(x["consistency_pair"] is not None and x["id"] not in (a+"01",a+"02") for x in xs if x["axis"]==a) or pair[0].get("consistency_relation")!="soft_opposed" or pair[1].get("consistency_relation")!="soft_opposed": raise ReferenceError(f"{a}: consistency pair 合约非法")
      if not pair[0]["consistency_pair"] or pair[0]["consistency_pair"]!=pair[1]["consistency_pair"]: raise ReferenceError(f"{a}: 必需配对标识不一致")
      if pair[0]["facet"]!=FACETS[a][0] or pair[1]["facet"]!=FACETS[a][0] or pair[0]["direction"]!=1 or pair[1]["direction"]!=-1 or pair[0]["expected_discrimination"]!="high" or pair[1]["expected_discrimination"]!="high": raise ReferenceError(f"{a}: 固定锚点合约非法")
      for suffix,facet,direction in (("17",FACETS[a][1],1),("30",FACETS[a][2],-1)):
        anchor=byid.get(a+suffix)
        if anchor is None or anchor["facet"]!=facet or anchor["direction"]!=direction or anchor["expected_discrimination"]!="high": raise ReferenceError(f"{a}: 固定锚点合约非法")
    return byid
def rank(seed, attempt, axis, facet, direction, iid, priority=1, ns=SAMPLING_VERSION):
    s=f"{ns}|{seed}|{attempt}|{axis}|{facet}|{direction}|{iid}"
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],"big") // priority
def eligible(x): return not x.get("extreme",False) and x.get("expected_discrimination") != "low"
def excluded(x, selected):
    e=set(x.get("excludes",[]))
    return bool(e & set(selected)) or any(x["id"] in set(y.get("excludes",[])) for y in selected.values())
def select(bank, seed):
    if not isinstance(seed,str): raise ReferenceError("seed 必须为字符串")
    byid=items_of(bank); fixed=[]
    for n in ("01","17","30","02"):
      for a in AXES: fixed.append(a+n)
    # specified display order is number-major then axis-major
    chosen={i:byid[i] for i in fixed if i in byid}
    if len(chosen)!=16: raise ReferenceError("固定基础16题缺失")
    if any(not eligible(x) for x in chosen.values()): raise ReferenceError("固定基础题不符合候选资格")
    if any(set(x["excludes"]) & set(fixed) for x in chosen.values()): raise ReferenceError("固定基础题之间不得互斥")
    for family in {x["family"] for x in chosen.values()}:
      members={i for i,x in chosen.items() if x["family"]==family}
      if len(members)>1 and not any(members=={a+"01",a+"02"} for a in AXES): raise ReferenceError("固定基础题有非检查对的重复 family")
    for attempt in range(512):
      cur=dict(chosen); families=Counter(x.get("family") for x in cur.values())
      ok=True
      for a in AXES:
       for f in FACETS[a]:
        for d in (1,-1):
          have=sum(x["axis"]==a and x["facet"]==f and x["direction"]==d for x in cur.values())
          need=2-have
          pool=[x for x in byid.values() if x["axis"]==a and x["facet"]==f and x["direction"]==d and x["id"] not in cur and eligible(x)]
          pool.sort(key=lambda x:(rank(seed,attempt,a,f,d,x["id"],2 if x["expected_discrimination"]=="high" else 1),x["id"]))
          for x in pool:
            if need<=0: break
            fam=x.get("family")
            # Only the designated 01/02 pair may repeat a family.
            if families[fam] and not ({x["id"]} | {y["id"] for y in cur.values() if y.get("family")==fam}) <= {a+"01",a+"02"}: continue
            if excluded(x,cur): continue
            cur[x["id"]]=x; families[fam]+=1; need-=1
          if need: ok=False; break
        if not ok: break
       if not ok: break
      if not ok: continue
      counts=Counter(c for x in cur.values() for c in x.get("contexts",[]))
      if any(counts[k]<v for k,v in QUOTAS.items()): continue
      if any(len(set(c for x in cur.values() if x["axis"]==a for c in x.get("contexts",[])))<4 for a in AXES): continue
      extra=[]
      for a in AXES:
       xs=[x for i,x in cur.items() if i not in fixed and x["axis"]==a]
       xs.sort(key=lambda x:(rank(seed,attempt,a,"display",0,x["id"],ns="16shadows-display-1"),x["id"]))
       if len(xs)!=8: raise ReferenceError("抽样内部错误：每轴补题不是8题")
       extra.append(xs)
      ordered=fixed + [extra[a][j]["id"] for j in range(8) for a in range(4)]
      formid=digest({"bank_digest":digest(bank),"sampling_version":SAMPLING_VERSION,"ordered_ids":ordered})
      versions={**BANK_IDENTITY,"form_schema":"open-reference-form-1","sampling":SAMPLING_VERSION}
      return {"schema_version":"open-reference-form-1","versions":versions,"sampling_version":SAMPLING_VERSION,"seed":str(seed),"attempt":attempt,"bank_digest":digest(bank),"ordered_ids":ordered,"form_id":formid}
    raise ReferenceError("512 次抽样均无法同时满足上下文配额；请核查题库覆盖与排斥条件，未改变 seed 或放宽规则")

def validate_form(bank, form):
    if not isinstance(form,dict): raise ReferenceError("form 须为对象")
    byid=items_of(bank); ids=form.get("ordered_ids")
    if not isinstance(ids,list) or len(ids)!=48 or any(not isinstance(i,str) for i in ids) or len(set(ids))!=48 or any(i not in byid for i in ids): raise ReferenceError("form 的 ordered_ids 非法")
    if form.get("bank_digest")!=digest(bank): raise ReferenceError("form 与 bank digest 不匹配")
    expected=digest({"bank_digest":digest(bank),"sampling_version":form.get("sampling_version"),"ordered_ids":ids})
    if form.get("form_id")!=expected: raise ReferenceError("form_id 不匹配")
    expected_versions={**BANK_IDENTITY,"form_schema":"open-reference-form-1","sampling":SAMPLING_VERSION}
    if form.get("schema_version")!="open-reference-form-1" or form.get("versions")!=expected_versions or form.get("sampling_version")!=SAMPLING_VERSION or not isinstance(form.get("seed"),str) or type(form.get("attempt")) is not int: raise ReferenceError("form 元数据非法")
    # A self-consistent checksum alone is not authority: replay the public blueprint.
    replay=select(bank,form["seed"])
    if form != replay: raise ReferenceError("form 不等于由当前 bank、seed 和正式抽样蓝图可重放的结果")
    if any(byid[ids[i]]["axis"]==byid[ids[i+1]]["axis"] for i in range(47)): raise ReferenceError("form 相邻题轴重复")
    for i,x in enumerate(ids):
      for j in range(i+1,min(48,i+8)):
        if byid[x]["family"]==byid[ids[j]]["family"]: raise ReferenceError("form 同 family 距离不足 8")
    return byid,ids
def answer_map(ids, answers, stage):
    need=ids[:16] if stage=="basic" else ids
    accepted=(set(need),set(ids)) if stage=="basic" else (set(ids),)
    if not isinstance(answers,dict) or set(answers) not in accepted: raise ReferenceError("answers 必须恰好包含当前 stage 的题号；basic 也可带完整48题（缺答写 null）")
    for i,r in answers.items():
      if r is not None and (type(r) is not int or not 1<=r<=5): raise ReferenceError(f"{i}: 答案须为 1..5 整数或 null")
    return answers
def axis_result(axis, rows, stage):
    valid=[(x,r) for x,r in rows if r is not None]
    plus=[(x,r) for x,r in valid if x["direction"]==1]; minus=[(x,r) for x,r in valid if x["direction"]==-1]
    facets={x["facet"] for x,r in valid}; contexts={c for x,r in valid for c in x.get("contexts",[])}; families={x.get("family") for x,r in valid}
    def mean(xs):
      return sum(Fraction(r-3,2)*Fraction(str(x.get("primary_weight",1))) for x,r in xs)/sum(Fraction(str(x.get("primary_weight",1))) for x,r in xs)
    plus_mean=mean(plus) if plus else None
    minus_mean=mean(minus) if minus else None
    raw=None if not plus or not minus else (plus_mean-minus_mean)/2
    threshold = (3,1,2) if stage=="basic" else (8,3,3)
    usable=len(valid)>=threshold[0] and len(plus)>=threshold[1] and len(minus)>=threshold[1] and len(facets)>=threshold[2]
    pairs=defaultdict(list)
    # Keep skipped designated pairs visible as unevaluated; absence is not evidence.
    for x,r in rows:
      if x.get("consistency_pair"): pairs[x["consistency_pair"]].append((x,r))
    tensions=[]; incomplete=[]
    for p,xs in pairs.items():
      if len(xs)==2 and all(r is not None for x,r in xs):
        (a,ra),(b,rb)=xs
        if abs(a["direction"]*(ra-3)/2-b["direction"]*(rb-3)/2)>=1.5: tensions.append(p)
      else: incomplete.append(p)
    stable=[]
    if raw is not None:
      for fam in families:
        sub=[z for z in valid if z[0].get("family")!=fam]; pp=[z for z in sub if z[0]["direction"]==1]; mm=[z for z in sub if z[0]["direction"]==-1]
        if pp and mm:
          s=(mean(pp)-mean(mm))/2; stable.append((s>0)==(raw>0) and s!=0)
    stability=None if raw in (None,0) or not stable else sum(stable)/len(stable)
    if not usable: level="unavailable"
    elif stage=="basic": level="low"
    elif abs(raw)>=Fraction(1,4) and len(valid)>=10 and len(plus)>=4 and len(minus)>=4 and len(facets)==3 and len(contexts)>=5 and len(families)>=8 and stability is not None and stability>=.9 and not incomplete and not tensions: level="higher"
    elif abs(raw)>=Fraction(1,10) and stability is not None and stability>=.75 and len(contexts)>=4 and not tensions: level="moderate"
    else: level="low"
    display=None if not usable else 50+50*raw
    percent=None if display is None else (2*display.numerator+display.denominator)//(2*display.denominator)
    official=raw if usable else None
    return {"score":None if official is None else float(official),"raw_score":None if raw is None else float(raw),"pole_means":{"positive":None if plus_mean is None else float(plus_mean),"negative":None if minus_mean is None else float(minus_mean)},"percent":percent,"direction":None if official is None or official==0 else ("positive" if official>0 else "negative"),"boundary":None if official is None else abs(official)<Fraction(1,10),"direction_confidence":{"level":level,"heuristic_unvalidated":True,"valid_count":len(valid),"direction_counts":{"positive":len(plus),"negative":len(minus)},"facet_count":len(facets),"context_count":len(contexts),"distinct_family_count":len(families),"pair_tensions":tensions,"unevaluated_pairs":incomplete,"leave_one_family_out_direction_stability":stability},"secondary_diagnostic":[x["id"] for x,r in valid if x.get("secondary")]}
def type_result(results):
    signs=[]; leading=[]; all_nonzero=True
    for a in AXES:
      s=results[a]["score"]
      direction=results[a]["direction"]
      if s is None or direction is None: all_nonzero=False
      leading.append(None if direction is None else direction=="positive")
      signs.append(None if s is None or results[a]["boundary"] else direction=="positive")
    candidates=[]
    for n in range(16):
      bits=[bool(n&8),bool(n&4),bool(n&2),bool(n&1)]
      if all(v is None or v==b for v,b in zip(signs,bits)): candidates.append({"id":f"T{n+1:02d}","name":NAMES[n]})
    if all_nonzero:
      n=sum(bit for bit,v in zip((8,4,2,1),leading) if v)
      primary={"id":f"T{n+1:02d}","name":NAMES[n]}
    else: primary=None
    return {"primary":primary,"candidates":candidates}
def score(bank, form, answers, stage="full"):
    if stage not in ("basic","full"): raise ReferenceError("stage 仅可为 basic 或 full")
    byid,ids=validate_form(bank,form); answers=answer_map(ids,answers,stage); use=ids[:16] if stage=="basic" else ids
    rs={a:axis_result(a,[(byid[i],answers[i]) for i in use if byid[i]["axis"]==a],stage) for a in AXES}
    vals=[answers[i] for i in use if answers[i] is not None]
    versions={**BANK_IDENTITY,"implementation_version":IMPLEMENTATION_VERSION,"score_schema":"open-reference-score-1","sampling":form["sampling_version"]}
    return {"schema_version":"open-reference-score-1","versions":versions,"sampling_version":form["sampling_version"],"score_profile":SCORE_PROFILE,"itemset":{"form_id":form["form_id"],"ordered_ids":use,"stage":stage},"bank_digest":digest(bank),"axes":rs,"type":type_result(rs),"flat_response":len(vals)>1 and len(set(vals))==1,"secondary_scoring_enabled":False}
def main():
 p=argparse.ArgumentParser(); q=p.add_subparsers(dest="cmd",required=True)
 a=q.add_parser("select"); a.add_argument("--bank",required=True); a.add_argument("--seed",required=True); a.add_argument("--out")
 b=q.add_parser("score"); b.add_argument("--bank",required=True); b.add_argument("--form",required=True); b.add_argument("--answers",required=True); b.add_argument("--stage",default="full",choices=("basic","full"))
 z=p.parse_args()
 try:
  out=select(load(z.bank),z.seed) if z.cmd=="select" else score(load(z.bank),load(z.form),load(z.answers),z.stage)
  blob=json.dumps(out,ensure_ascii=False,indent=2)+"\n"
  if z.cmd=="select" and z.out:
   with open(z.out,"w",encoding="utf-8") as f:f.write(blob)
  else: sys.stdout.write(blob)
 except (OSError,json.JSONDecodeError,ReferenceError) as e:
  print(f"error: {e}",file=sys.stderr); return 2
if __name__=="__main__": sys.exit(main())
