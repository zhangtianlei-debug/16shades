"""Synthetic fixtures test mechanics only, never human validity."""
import copy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import shadows

def bank():
    return shadows.load(Path(__file__).resolve().parents[1]/"bank/items.json")
def answers(form, value=3, stage="full"):
    ids=form["ordered_ids"][:16] if stage=="basic" else form["ordered_ids"]
    return {i:value for i in ids}

class ReferenceTests(unittest.TestCase):
 def setUp(self): self.b=bank(); self.f=shadows.select(self.b,"gold")
 def test_seed_replay_order_spacing(self):
  self.assertEqual(self.f,shadows.select(self.b,"gold")); self.assertNotEqual(self.f["ordered_ids"],shadows.select(self.b,"different")["ordered_ids"])
  ids=self.f["ordered_ids"]; by=shadows.items_of(self.b)
  self.assertEqual(ids[:16],[a+n for n in ("01","17","30","02") for a in shadows.AXES])
  self.assertTrue(all(by[ids[i]]["axis"]!=by[ids[i+1]]["axis"] for i in range(47)))
  self.assertTrue(all(by[ids[i]]["family"]!=by[ids[j]]["family"] for i in range(48) for j in range(i+1,min(48,i+8))))
 def test_all_16_mappings(self):
  for n in range(16):
   rs={a:{"score":1 if n&bit else -1,"direction":"positive" if n&bit else "negative","boundary":False} for a,bit in zip(shadows.AXES,(8,4,2,1))}
   self.assertEqual(shadows.type_result(rs)["primary"]["id"],f"T{n+1:02d}")
 def test_hand_gold_extreme_neutral_null(self):
  by=shadows.items_of(self.b); ex={i:5 if by[i]["direction"]==1 else 1 for i in self.f["ordered_ids"]}
  out=shadows.score(self.b,self.f,ex); self.assertEqual(out["axes"]["G"]["score"],1); self.assertEqual(out["type"]["primary"]["id"],"T16")
  self.assertIsNone(shadows.score(self.b,self.f,answers(self.f,3))["type"]["primary"])
  self.assertEqual(shadows.score(self.b,self.f,answers(self.f,1))["axes"]["G"]["score"],0)
  self.assertEqual(shadows.score(self.b,self.f,answers(self.f,5))["axes"]["G"]["score"],0)
  self.assertTrue(shadows.score(self.b,self.f,answers(self.f,1))["flat_response"])
  self.assertIsNone(shadows.score(self.b,self.f,answers(self.f,None))["axes"]["G"]["score"])
 def test_basic_only_prefix_and_threshold(self):
  a=answers(self.f,3,"basic"); self.assertIn("axes",shadows.score(self.b,self.f,a,"basic"))
  self.assertEqual(shadows.score(self.b,self.f,answers(self.f,3),"basic")["itemset"]["ordered_ids"],self.f["ordered_ids"][:16])
  a["G01"]=a["G17"]=None; self.assertIsNone(shadows.score(self.b,self.f,a,"basic")["axes"]["G"]["score"])
  full=answers(self.f,3); [full.__setitem__(i,None) for i in self.f["ordered_ids"] if i.startswith("G")]
  self.assertIsNone(shadows.score(self.b,self.f,full)["axes"]["G"]["score"])
 def test_answers_and_stage_errors(self):
  a=answers(self.f); a["X99"]=3
  with self.assertRaises(shadows.ReferenceError): shadows.score(self.b,self.f,a)
  a=answers(self.f); a[next(iter(a))]=True
  with self.assertRaises(shadows.ReferenceError): shadows.score(self.b,self.f,a)
  with self.assertRaises(shadows.ReferenceError): shadows.score(self.b,self.f,answers(self.f),"unknown")
  with self.assertRaises(shadows.ReferenceError): shadows.score(self.b,self.f,{})
 def test_form_replay_blocks_resigned_tamper(self):
  for change in (lambda f:f.update(bank_digest="0"*64),lambda f:f["ordered_ids"].__setitem__(16,f["ordered_ids"][20])):
   f=copy.deepcopy(self.f); change(f); f["form_id"]=shadows.digest({"bank_digest":f["bank_digest"],"sampling_version":f["sampling_version"],"ordered_ids":f["ordered_ids"]})
   with self.assertRaises(shadows.ReferenceError): shadows.score(self.b,f,answers(self.f))
 def test_bad_bank_and_no_form(self):
  for key,value in (("primary_weight",True),("primary_weight",float("nan")),("primary_weight",float("inf")),("primary_weight",10**400),("direction",0),("contexts",["bad"]),("expected_discrimination","real")):
   b=bank(); b["items"][0][key]=value
   with self.assertRaises(shadows.ReferenceError): shadows.select(b,"x")
  b=bank(); [x.update(contexts=["low_stakes","rules"]) for x in b["items"]]
  with self.assertRaisesRegex(shadows.ReferenceError,"512 次抽样"): shadows.select(b,"x")
 def test_exclusion_family_infeasible(self):
  b=bank()
  for x in b["items"]:
   if x["id"].startswith("G") and x["facet"]=="tradeoff" and x["direction"]==1 and x["id"]!="G01": x["extreme"]=True
  with self.assertRaises(shadows.ReferenceError): shadows.select(b,"x")
 def test_half_up_golden(self):
  rows=[({"direction":1,"facet":"a","contexts":[],"family":"p","primary_weight":1},4),({"direction":-1,"facet":"b","contexts":[],"family":"m","primary_weight":1},3),({"direction":1,"facet":"c","contexts":[],"family":"p2","primary_weight":1},4)]
  r=shadows.axis_result("G",rows,"basic"); self.assertEqual(r["score"],.25); self.assertEqual(r["percent"],63)
 def test_honesty_and_weight_scale(self):
  out=shadows.score(self.b,self.f,answers(self.f)); self.assertNotIn("answers",str(out)); self.assertTrue(out["axes"]["G"]["direction_confidence"]["heuristic_unvalidated"]); self.assertNotIn("probability",str(out).lower())
  by=shadows.items_of(self.b)
  a={i:4 if by[i]["direction"]==1 else 3 for i in self.f["ordered_ids"]}
  one=shadows.score(self.b,self.f,a); b=copy.deepcopy(self.b); [x.update(primary_weight=1.5) for x in b["items"]]; f=shadows.select(b,"gold")
  self.assertEqual(one["axes"]["G"]["score"],.25)
  self.assertEqual(one["axes"]["G"]["score"],shadows.score(b,f,a)["axes"]["G"]["score"])
 def test_exact_boundary_and_nonzero_leading(self):
  rows=[]
  for sign in (1,-1):
   for n in range(5):
    rows.append(({"direction":sign,"facet":str(n%3),"contexts":["rules","low_stakes"],"family":f"{sign}-{n}","primary_weight":1},5 if sign==1 and n==0 else 3))
  r=shadows.axis_result("G",rows,"full")
  self.assertEqual(r["score"],.1); self.assertFalse(r["boundary"])
  rows[0]=(rows[0][0],4); r=shadows.axis_result("G",rows,"full")
  self.assertTrue(r["boundary"])
  t=shadows.type_result({a:r for a in shadows.AXES})
  self.assertEqual(t["primary"]["id"],"T16"); self.assertEqual(len(t["candidates"]),16)
 def test_nonuniform_weights_have_real_effect(self):
  rows=[({"direction":1,"facet":"a","contexts":[],"family":"p1","primary_weight":1.5},5),({"direction":1,"facet":"b","contexts":[],"family":"p2","primary_weight":.5},1),({"direction":-1,"facet":"c","contexts":[],"family":"m","primary_weight":1},3)]
  self.assertEqual(shadows.axis_result("G",rows,"basic")["score"],.25)
  for x,r in rows:x["primary_weight"]=1
  self.assertEqual(shadows.axis_result("G",rows,"basic")["score"],0)
 def test_fixed_excludes_cannot_be_bypassed(self):
  b=bank(); by={x["id"]:x for x in b["items"]}
  by["G01"]["excludes"]=["G02"]; by["G02"]["excludes"]=["G01"]
  with self.assertRaisesRegex(shadows.ReferenceError,"固定基础题之间不得互斥"):shadows.select(b,"x")
 def test_bad_shapes_required_fields_and_secondary(self):
  for value in (None,[],{}):
   with self.assertRaises(shadows.ReferenceError):shadows.items_of(value)
  b=bank(); b["items"][0]=None
  with self.assertRaises(shadows.ReferenceError):shadows.items_of(b)
  for key in ("expected_basis","empirical_discrimination","excludes"):
   b=bank(); del b["items"][0][key]
   with self.assertRaises(shadows.ReferenceError):shadows.items_of(b)
  for axis,direction in (("G",1),("M",True),(None,1)):
   b=bank(); b["items"][0]["secondary"]=[{"axis":axis,"direction":direction,"proposed_weight":.2,"rationale":"synthetic"}]
   with self.assertRaises(shadows.ReferenceError):shadows.items_of(b)
 def test_full_eight_and_seven_gate(self):
  by=shadows.items_of(self.b); a=answers(self.f,4); ids=[i for i in self.f["ordered_ids"] if i.startswith("G")]
  keep=[i for d in (1,-1) for i in [j for j in ids if by[j]["direction"]==d][:4]]
  for i in ids:
   if i not in keep:a[i]=None
  self.assertIsNotNone(shadows.score(self.b,self.f,a)["axes"]["G"]["score"])
  a[keep[-1]]=None; r=shadows.score(self.b,self.f,a)["axes"]["G"]
  self.assertIsNone(r["score"]); self.assertIsNone(r["direction"]); self.assertIsNotNone(r["raw_score"])
 def test_json_duplicates_and_cli_failure(self):
  with tempfile.TemporaryDirectory(prefix="shadows-test-") as tmp:
   p=Path(tmp)/"invalid.json"
   for value in ('{"G01":2,"G01":5}','{"G01":NaN}'):
    p.write_text(value,encoding="utf-8")
    with self.assertRaises(shadows.ReferenceError):shadows.load(p)
   p.write_text('{}',encoding="utf-8")
   r=subprocess.run([sys.executable,str(Path(shadows.__file__)),"select","--bank",str(p),"--seed","x"],capture_output=True,text=True)
   self.assertEqual(r.returncode,2);self.assertIn("error:",r.stderr)
if __name__=="__main__": unittest.main()
