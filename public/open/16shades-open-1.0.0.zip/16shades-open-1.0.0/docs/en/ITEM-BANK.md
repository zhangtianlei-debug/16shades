# English Item-Bank Overlay

This is an English-language editorial overlay for the Chinese source bank. It is not a second scoring bank, a replacement form, or evidence of cross-language equivalence. Merge each entry with the source item in [`../../standard/bank/items.json`](../../standard/bank/items.json) by its stable `id`; the Chinese source remains authoritative for machine identity and scoring metadata. In particular, do not recreate or substitute `axis`, `facet`, `direction`, `family`, `excludes`, `contexts`, weights, form selection, `form_id`, or `bank_digest` from this overlay.

`source_bank_digest` is copied from the current website candidate form solely to identify the compatible source snapshot. It does not change that digest or form ID.

## Coverage and text provenance

All 160 source IDs have one English entry. The current website’s fixed 48 are: G01, G02, G03, G08, G17, G20, G21, G22, G29, G30, G32, G37, M01, M02, M12, M15, M17, M19, M22, M24, M30, M33, M37, M38, H01, H02, H03, H14, H17, H20, H22, H25, H30, H35, H39, H40, N01, N02, N06, N15, N17, N24, N25, N28, N30, N31, N35, N40. Their `text` values are copied verbatim from `app/i18n/en.json`, keyed by the corresponding Chinese source text, and have `translation_source: website-en-snapshot`. If an integration can supply both this overlay and the website snapshot, those 48 texts take priority.

The other 112 entries are `candidate-editorial-translation`: English editorial translations of candidate-bank text. They are supplied for reading and research preparation only. There is no random English form, linguistic-equivalence claim, calibration transfer, score comparability claim, or language-validation claim. The overlay status is therefore `editorial_unvalidated`.

## Field meaning

The overlay deliberately carries only language-dependent fields plus `id`. `mechanism`, `expected_basis`, `confound_risks`, and every `secondary.rationale` are translated individually from their Chinese-source counterparts. They are not collapsed to axis- or facet-level boilerplate. `secondary` preserves its source structure (`axis`, `direction`, `proposed_weight`, and `rationale`) and is still not scored in this version.

`family`, `excludes`, `facet`, `contexts`, `expected_discrimination`, and related fields remain source-bank metadata. A family marks related scenarios; excludes prevent unsuitable same-form combinations; facets and contexts describe intended content coverage and scenario conditions. `expected_discrimination` is an editorial prior, while `empirical_discrimination` in the source is unestimated; neither is a measured parameter in this overlay. These fields do not establish psychological factors, diagnostic validity, or measured language equivalence.

## Response options

The six English response labels are copied verbatim from `app/i18n/en.json`. The null option is `Unsure / Skip`; it is not the midpoint response.

## Integration rule

1. Load the [Chinese source bank](../../standard/bank/items.json) and its selected form as the source of machine-readable identity, selection, exclusions, and scoring.
2. Load this [English overlay](../../data/bank.en.json).
3. Join this overlay by `id` only.
4. For the current fixed 48, use the website snapshot text above before any independently edited English variant.
5. Treat the remaining 112 translations as unvalidated research-candidate wording. Do not silently use them to create a new English scoring form or compare English and Chinese scores.
