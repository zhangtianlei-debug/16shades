# Reference Test and Sampling Contract

**Package:** 1.0.0. **Normative sampling component:** 1.0.0-draft.1; source: [D · Random Item Sampling Rules](../../standard/D_随机抽题规则.md). Sampling identity is `16shadows-sampling-1`; display identity is `16shadows-display-1`.

The recommended public exploratory form is the fixed 48-item form. Constrained random forms are for research or limited trials: shared anchors do not establish statistical form equivalence, and random-form differences are not personality change.

The current website consumes a versioned fixed snapshot; it does not generate a random form for each respondent. These seed/attempt rules apply to reference or research form generation.

## Fixed prefix and hard quotas

The first 16 positions are fixed, in this exact order:

```
G01 M01 H01 N01  G17 M17 H17 N17  G30 M30 H30 N30  G02 M02 H02 N02
```

They provide four items per axis, two directions per axis, all three facets, and the paired 01/02 soft check separated by 12 positions. Basic does not claim full-form context coverage.

A full form has 48 items: 12 per axis; 4 per facet; 2 positive and 2 negative per axis×facet; 24 per direction overall; no `extreme=true` or `expected_discrimination=low`; at least 4 context tags per axis; no mutually excluded items; and at most one member of each family, except the fixed 01/02 consistency pair. Its global minima are: resource conflict 4, authority asymmetry 4, rules 4, private relationship 4, strangers 4, competition 4, retaliation 4, anonymous 2, public 4, high stakes 2, low stakes 8, weaker other 2, stronger other 2, sanction risk 2, low sanction risk 2. Tags can satisfy multiple minima; do not fabricate tags. High stakes and sanction risk are separate conditions.

## Eligibility, selection, and bounded retry

Validate bank fields and identity, add anchors, then process axes `G,M,H,N`; within each use the bank’s facet order and directions `+1,-1`; fill every axis×facet×direction cell to two items. Exclude selected items, extreme/low items, exclusions, and same-family items (aside from fixed 01/02). Selection never uses a respondent’s answers.

Facet order is fixed: G `tradeoff, delegation, allocation`; M `channel, leverage, resistance`; H `closure, recognition, persistence`; N `justification, audience, challenge`.

For every `attempt` from `0` through `511`, each candidate’s UTF-8 input is:

```
16shadows-sampling-1|{seed}|{attempt}|{axis}|{facet}|{direction}|{id}
```

`seed` is any UTF-8 string and must be fully recorded. Direction is literal `1` or `-1`; attempt is decimal without leading zeros. Let `u` be the first 8 SHA-256 bytes as an unsigned **big-endian** integer. Let priority be 2 for `high`, 1 for `medium`, and `rank = u // priority`. Sort ascending by rank, then lexicographic ID. Priority is an editorial selection tilt, not a score weight or information estimate.

After filling, validate every global quota and exclusion. On failure discard additions, retain only anchors, and retry. After all 512 attempts, return the explicit error: `current rules found no form satisfying quotas`. Do not relax quotas, replace the seed, or insert low-quality items.

## Display order and form identity

Keep anchors fixed. Sort each axis’s remaining eight items using:

```
16shadows-display-1|{seed}|{attempt}|{axis}|display|0|{id}
```

Use the same SHA-256 first-eight-byte big-endian rule, no priority division, and lexicographic ID tiebreak. Emit the sorted groups in eight interleaved rounds `G,M,H,N`; adjacent items therefore have different primary axes. Same-family positions must be at least 8 apart (the fixed pair is 12).

Canonical JSON is UTF-8; object keys lexicographically sorted; no unnecessary whitespace; comma/colon separators; non-ASCII characters unescaped; array order preserved; and duplicate keys and non-finite numbers rejected. It is the contract for this reference JSON, not a claim of universal numeric serialization.

```
bank_digest = SHA256(canonical JSON of entire bank)
form_id = SHA256(canonical JSON of {
  "bank_digest": bank_digest,
  "sampling_version": "16shadows-sampling-1",
  "ordered_ids": [display-order 48 IDs]
})
```

Record schema, all precise version identities, seed, attempt, bank digest, ordered IDs, and form ID. A metadata-only bank change changes its digest; seed alone does not identify a form, while identical bank and ordered IDs can share a form ID. See [Scoring](SCORING.md) for the scored-result contract.
