# Citation, License and Release Status

This is a public-release-prepared package, sealed locally on 2026-09-22 as version 1.0.0. It was not uploaded to GitHub, used to create a repository, or deployed to the website when sealed.

The planned public repository is https://github.com/zhangtianlei-debug/16shades-open. The planned website download is https://shades16.com/open/16shades-open-1.0.0.zip and the planned web explanation is https://shades16.com/about#openness. These are targets, not claims of current publication.

## Citation

> 16 Shades / 16暗影. *Bilingual Open Materials*. Version 1.0.0, 2026-09-22; standard components 1.0.0-draft.1; corresponding recorded website version beta-accounts-5. MIT for code and CC BY 4.0 for framework, item bank, documentation, and translations.

Research and integration records should also identify the components used, bank digest, form ID, stage, actual presentation locale, and presentation version. CITATION.cff is machine-readable metadata; it does not invent a DOI, public repository, or publication record.

## License and scope

Code is licensed under MIT. The self-owned classification framework, item bank, documentation, and translations are licensed under CC BY 4.0. The exact path scope, attribution requirements, and brand exceptions are in [LICENSE.md](../../LICENSE.md).

Official character art, animation, logos, visual brand assets, fonts, collaborations, account services, databases, real answers, contact information, and credentials are excluded. Character and project names appear only for technical mapping and attribution; this package grants no trademark, endorsement, or visual-brand permission.

Older private-candidate wording in the standard directory is an archived snapshot and does not override the root license scope.

## Evidence boundary

The package reproduces only the fixed assessment's numerical behavior and listed language material; it is not a website clone. Offline checks establish engineering conformance and translation coverage for stated inputs; they do not establish personality validity, psychometric properties, or cross-language equivalence.
