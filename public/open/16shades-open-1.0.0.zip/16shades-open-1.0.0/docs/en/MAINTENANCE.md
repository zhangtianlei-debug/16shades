# Maintainer Notes

Researchers and integrators only need the root README and the verification command. This is a standalone snapshot: the primary verification, examples, and sealing process do not read the original project, use a network, or upload content.

Editing sources are the archived standard snapshot, the fixed form and scoring source in website, the English overlay in data/bank.en.json, and this package's adapters and bilingual documents. Do not edit only generated question tables, examples, expected results, schemas, or scoring JavaScript.

    packaged bank + data/bank.en.json + integration
      -> tools/refresh_derived.py -> examples, docs, schemas
    complete package + licenses + acceptance notes
      -> tools/seal.py -> release-manifest.json + ZIP + SHA-256

Start each new version by copying a sealed package and recording its source, date, changes, and new version. Do not overwrite an existing final ZIP. Before changing an item bank, scoring behavior, or website snapshot, audit its source separately in the project maintenance environment; bring only public-safe results with no secrets, personal data, or brand assets into the new package.

From the package root:

    python3 tools/refresh_derived.py
    python3 verification/verify.py --draft --node /absolute/node
    python3 tools/seal.py --output-dir /delivery/outside/package
    python3 verification/verify.py --node /absolute/node

The sealing tool rejects a different overwrite of an existing ZIP. Extract the ZIP to an independent temporary directory and run full verification; save the output next to the ZIP rather than inside it, to avoid a manifest-hash cycle.

If licensing, a public channel, or brand scope changes, update root LICENSE.md, README, CITATION.cff, release manifest, and these notes, then reseal and verify.
