# Fixed Assessment Integration

This entry supports the website’s fixed 16/48-item contract in Chinese and English, with matching Python and JavaScript outputs. See [version scope](VERSIONS.md). No website API, account, key, database, or external service is required.

## JavaScript

Create a script at the package root or adjust the relative import:

```js
import {getForm, scoreFixed} from './integration/fixed.mjs';
const basic = getForm('basic', 'en');
// items are ordered {id,text}; response_options contains all six options.
// Keep untouched controls separate in UI state. Do not silently submit 3 or null.
const answers16 = Array(16).fill(3); // Synthetic demo; real users must choose.
const initial = scoreFixed(answers16, 'basic', 'en');
const full = getForm('full', 'en');
const remaining = full.items.slice(16); // Preserve the first 16 answers.
const answers48 = [...answers16, ...Array(32).fill(3)]; // Synthetic demo
const updated = scoreFixed(answers48, 'full', 'en');
console.log(updated.result.primary); // All neutral: null, never forced T01.
```

`getForm` returns a detached copy; consumer edits cannot alter the scoring form. Node examples run directly. For browsers, import through your own build system or serve the form/results from your own backend. No webpage UI is included, and browser integrations are not claimed as tested.

## Python

```python
from integration.fixed import get_form, score_fixed
form = get_form('full', 'zh-CN')
answers = [3] * 48  # Synthetic example, never default answers for users
output = score_fixed(answers, 'full', 'zh-CN')
assert output['result']['primary'] is None
```

Both adapters accept an array in the exact fixed order: 16 entries for `basic`, 48 for `full`. Each is an integer 1–5 or an explicitly chosen skip, `null` (`None` in Python). Holes, missing/extra entries, booleans, strings, and out-of-range values are rejected. An explicit midpoint `3` differs from a skipped answer. Supported locales are `zh-CN` and `en`; unknown locales do not silently fall back.

The full result recalculates all 48 answers once. It neither doubles the weight of the first 16 nor locks the initial type. Retain answers only as needed to continue the current session; define your own exit, expiry, and persistence policy. Examples do not retain real answers, upload them, or send analytics.

## Result fields and presentation

The envelope has `schema=16shadows-integration-result-1`. `package_version` identifies the adapter. `presentation_locale` and `presentation_version` identify displayed wording. `result.versions.language` remains `zh-CN`, the scoring-bank identity; do not relabel it English while keeping the old digest.

| Field | Consumer behavior |
|---|---|
| `result.schema` | `prototype-fixed-form-1`, the website’s compact result |
| `result.bankDigest`, `result.formId`, `result.versions`, `result.stage` | Retain with results for exact provenance |
| `result.axes.G/M/H/N.score` | Continuous -1 to 1, or null if insufficient coverage |
| `percent` | Positive-pole integer reading; negative=`100-percent`; never a probability |
| `direction`, `boundary` | Leading pole or null; boundary indicator; never infer from rounded readings |
| `confidence`, `validCount` | Uncalibrated direction heuristic and valid-answer count |
| `result.primary` | T01–T16 or null; no unique type for exact ties or insufficient information |
| `result.candidates` | All non-excluded candidates in ID order, not a ranking |
| `result.flatResponse` | At least two valid answers all use one option; only a flag |
| `labels.axes`, `labels.types` | Localized names indexed by stable ID |
| `heuristic_unvalidated`, `language_equivalence_validated`, `notice` | Preserve validation status and show the corresponding explanation |

Use language such as “Your responses currently lean toward…” or “Some directions do not yet have a clear lead.” Do not replace a measured primary with a reading recommendation or a self-selected character. Native Python output retains additional diagnostics such as `pole_means`; see [full scoring](SCORING.md). The compact website object is not the complete research output.

## Errors and command line

Adapters raise an error with a stable `code`. Examples write `{code,message}` to stderr and exit 2 without echoing answers. Codes: `E_ANSWERS` invalid answers; `E_STAGE` unsupported stage; `E_LOCALE` unsupported locale; `E_FILE` unreadable or malformed JSON; `E_CONFIG` package mismatch; `E_USAGE` command syntax. Both languages are in [messages.json](../../integration/messages.json). An unsupported locale is reported in English.

```sh
node examples/node.mjs examples/basic.answers.json basic zh-CN
python3 examples/python.py examples/basic.answers.json basic en
```

Commands also run from another directory when script and input paths are correct. Do not put real answers in command arguments, URLs, or error logs. Example JSON is synthetic. [Answer schema](../../schemas/answers.schema.json) and [result schema](../../schemas/integration-result.schema.json) describe serialized structures; adapters enforce stage/count relationships.

## Original reference implementation

For complete diagnostics and ID-keyed input, the unchanged Python reference is available:

```sh
python3 standard/reference/shadows.py score --bank standard/bank/items.json --form standard/default_form.json --answers standard/verification/example_answers.json --stage full
python3 standard/reference/shadows.py select --bank standard/bank/items.json --seed reference-zh-CN-1
```

The original program only supports its Chinese self-report profile and retains historical Chinese errors. Use the adapters above for new bilingual fixed-form integrations. The English overlay is not a new `bank` accepted by that reference program. The fixed adapter also cannot score an arbitrary sampled research form.
