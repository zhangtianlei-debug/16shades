# Offline Verification

From the package root:

```sh
python3 verification/verify.py
```

Requires Python 3.9+ and Node.js 22.13+; tested with 3.9.6 and 24.19.0. Add `--node /absolute/path/to/node` if needed. Success exits 0 with JSON `status=passed`; a required-check failure exits 1. No network, account, original repository, or third-party dependency is needed. Temporary files contain only synthetic responses and are removed on exit.

## Coverage

1. Exact file set, byte lengths and SHA-256 manifest; every original proposal file matches its original manifest.
2. Bank digest, default seed replay, 48-item website order, metadata, versions and form identity.
3. Original independent quota logic over 100 seeds: axes/facets/directions, contexts, exclusions, family spacing and deterministic replay.
4. Twenty-four independently hand-specified golden cases and forty seeded synthetic answer inputs. Python, JavaScript, converted website source and deployed scoring functions are compared in both locales: 128 cross-runtime/deployment comparisons.
5. Sixteen original Python unit tests; adapter input errors, stage/locale handling, form-copy isolation; basic/full CLI examples in both languages against complete packaged expected results.
6. All 160 English IDs, nonempty fields, exact website wording/options for 48 items, translation provenance, secondary identity, per-item risk counts, and local links in new documentation.
7. Exclusion of account databases, environment secrets, dependencies, official image assets and symlinks.

Structural completeness does not prove translation meaning. Original-field correspondence and English specifications were also reviewed. See [bilingual acceptance](../ACCEPTANCE.md).

## Original checker versus portable entry

`standard/verification/check_release.py` is preserved unchanged. Its historical `main` checks provenance paths in the original product repository and can fail when those external documents are absent. The new `verification/verify.py` reuses its independent quota checks, substitutes packaged manifests/provenance for external path existence, and retains golden cases, 100 seeds and original unit tests. Use the command above for complete standalone verification.

The original unit tests can also be run separately:

```sh
python3 -B -m unittest discover -s standard/reference -p 'test_*.py' -v
```

## Extraction and integrity

The `.sha256` beside the ZIP checks the complete archive bytes. After extraction, the main command checks included files. Hashes detect changes or missing content; they do not independently authenticate authorship. Do not accept a delivered package using `--draft`: it is a maintainer-only switch that skips the final manifest and labels output `draft-unsealed`.

These are engineering checks, not psychometric, participant, or live-server verification. Seeds are not human samples; passing software does not establish language/form equivalence.
