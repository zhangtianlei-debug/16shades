# Research and Validation Boundaries

**Package:** 1.0.0. The corresponding component is `1.0.0-draft.1`; source: [H · Hypothesis Register and Validation Route](../../standard/H_假设登记与验证路线.md). This package provides definitions, candidate items, rules, reference behavior, and engineering checks. It contains no new participant data and makes no psychometric-validation claim.

Engineering reproducibility and psychometric evidence answer different questions. Fixed seeds, golden cases, and many simulated answers can show that software follows its rule; they cannot show that people understand items as intended, that an axis exists, that forms are equivalent, or that a result predicts behavior.

## Registered assumptions

| ID | Working assumption | Present status / future check |
|---|---|---|
| HYP01 | Four questions are conceptually distinguishable. | Argument only; check interviews and item relations; rewrite mixed items first. |
| HYP02 | Eight poles can be summarized as four contrasts. | May be coexisting tendencies; compare four-axis, eight-pole, and contextual models. |
| HYP03 | G captures gain/control tradeoff. | May include responsibility or risk aversion; vary expertise, costs, and control setting. |
| HYP04 | M captures influence path. | May reflect communication/management habit; compare with cooperation ability and resisted choices. |
| HYP05 | H distinguishes closure from extra reckoning. | Highest confound risk: legitimate accountability, repair, safety; ask why continuation is wanted and revise items. |
| HYP06 | N captures reliance on shared reasons. | May include rule-following, language skill, confidence, or different inner/outer motives; separate them. |
| HYP07 | Everyday items generalize to shadow-context strategy. | Core untested transfer claim; if unsupported, report everyday strategy only. |
| HYP08 | Sixteen types add explanatory value. | Defined regions are real; natural clusters are unproven; compare with continuous scores. |
| HYP09 | Five response levels are approximately averageable. | Engineering approximation; inspect option use and monotonicity. |
| HYP10 | `high` items discriminate better than `medium`. | Editorial prior only; test target/non-target relations and retest behavior. |
| HYP11 | Random forms with the same blueprint are close enough. | Structural match only; compare anchors, order effects, and retest; retain fixed default otherwise. |
| HYP12 | Sixteen items are a useful initial screen. | Likely less stable; compare independently completed 16/48 forms. |
| HYP13 | The 0.10 boundary and confidence thresholds are suitable. | Uncalibrated; inspect reversals and boundary experience through a new profile. |
| HYP14 | Soft pairs detect local tension. | Not deception detection; interview sources of tension and revise/remove confusing pairs. |
| HYP15 | Family deletion reflects directional robustness. | Only within-form sensitivity; compare later with retest and alternate forms. |
| HYP16 | Three facets cover each axis. | Content judgment; collect uncaptured examples and add items before adding user burden. |
| HYP17 | Different people and languages understand an item alike. | Unproven even for intended Chinese adults; evaluate group and translation differences. |
| HYP18 | Secondary proposals add useful evidence. | Editorial only and off in this version; test cross-axis relations independently or remove. |
| HYP19 | Equal weights are a better start than subjective complexity. | Transparent baseline; adopt calibrated weights only with held-out benefit. |
| HYP20 | Users will enjoy the experience and be willing to share it. | Product hypothesis, not psychometric evidence; inspect completion, skips, comprehension, and sharing feedback. |

## Proportionate next work

Current available human feedback is at most **three to four acquaintances**, using short chats. Use it to discover misunderstood wording, unintended moral pressure, confusing conditions, and actual-device experience—especially H, N, the 16-item prefix, and frequently skipped items. It is not statistical validation and must not be presented as such.

Formal recruitment, a large sample, and long multi-round surveys are not prerequisites for this candidate package. They are optional, separately authorized future empirical work. If it occurs, exploratory factor work, confirmatory testing on separate/held-out data, retest, parallel-form comparison, group/language checks, and item-response models each address distinct questions; no single internal-consistency statistic validates the framework.

For ordinary product use, do not silently retain item answers, place them in third-party analytics, error logs, or sharing URLs to calibrate the model. Any empirical collection requires its own explicit, voluntary research arrangement, minimal identity data, defined retention/access/withdrawal boundaries, and must not be made a condition of completing the ordinary test. No such collection begins with this package.

See [Framework](FRAMEWORK.md), [Scoring](SCORING.md), and [Sampling](SAMPLING.md).
