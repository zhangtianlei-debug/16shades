# All 160 Items and Fixed-Form Order

Generated from the packaged bank and English overlay. Numbers are positions in the website’s fixed 48; positions 1–16 are basic. — means the item is not in the website form. See [item-bank notes](ITEM-BANK.md) for metadata and editorial rules.

| ID | Axis / facet / direction | Website position | Wording |
|---|---|---:|---|
| G01 | G / tradeoff / 1 | 1 | When my team splits a bonus, I would accept a smaller share if I could keep the final say over the allocation. |
| G02 | G / tradeoff / -1 | 13 | When a group divides rewards, I don't mind who makes the final decision as long as I get a little more. |
| G03 | G / tradeoff / 1 | 37 | When choosing a shared home, I would pay more rent if it meant I could make the final decision on the location. |
| G04 | G / tradeoff / -1 | — | When someone offers me a larger share of the returns from a joint project, I can let them lead how it is done. |
| G05 | G / tradeoff / 1 | — | On a family trip, I would rather visit one fewer attraction if the itinerary follows my plan. |
| G06 | G / tradeoff / -1 | — | If switching seats in a queue would let me finish earlier, I do not mind a stranger arranging the order. |
| G07 | G / tradeoff / 1 | — | When a team competition offers prize money, I can take a smaller share as long as I decide the key strategy. |
| G08 | G / tradeoff / -1 | 25 | In a resale deal, if the price works for me, I do not mind letting the buyer or seller choose how we make the exchange. |
| G09 | G / tradeoff / 1 | — | When friends co-host an event, I would rather contribute more money and retain control over the guests and schedule. |
| G10 | G / tradeoff / -1 | — | When an online-game team divides equipment, I can follow someone else's lead as long as I get the items I need. |
| G11 | G / tradeoff / 1 | — | When a community vote concerns subsidies, I am willing to give up some subsidy in exchange for leading the proposal. |
| G12 | G / tradeoff / -1 | — | If a temporary job pays more, I can accept someone else deciding exactly how it is completed. |
| G13 | G / tradeoff / 1 | — | In a joint purchase, I would rather receive a smaller discount and choose the final brand myself. |
| G14 | G / tradeoff / -1 | — | If giving up the chair can bring in more resources, I am willing to let someone else chair the meeting. |
| G15 | G / tradeoff / 1 | — | After a major collaboration is agreed, I can take a smaller return, but important changes must have my approval. |
| G16 | G / tradeoff / -1 | — | When choosing a training course, I can accept whoever sets the course arrangements as long as the subsidy is higher. |
| G17 | G / delegation / 1 | 5 | After assigning a task to someone experienced, I still want to approve each critical step before they continue. |
| G18 | G / delegation / -1 | — | When I ask a friend to buy something for me, I am willing to let them choose it as long as the price and specifications are right. |
| G19 | G / delegation / 1 | — | When I ask a colleague to chair a meeting for me, I still require the agenda order to follow my decision. |
| G20 | G / delegation / -1 | 29 | When family members book a trip for me, I don't need to approve every detail as long as it stays within budget. |
| G21 | G / delegation / 1 | 41 | When a newcomer leads a project, I would accept slower progress to retain final approval. |
| G22 | G / delegation / -1 | 33 | When I hire a professional for a repair, I'm willing to accept their plan as long as it stays within budget. |
| G23 | G / delegation / 1 | — | When I am temporarily away from the group, I would rather wait to decide when I return than let everyone decide for me. |
| G24 | G / delegation / -1 | — | When a friend sells an unused item for me, they can decide how to negotiate as long as the price meets the target. |
| G25 | G / delegation / 1 | — | When I leave pet care to a family member, I am willing to spend more effort coordinating in order to retain control over the feeding schedule. |
| G26 | G / delegation / -1 | — | If letting a platform automatically allocate the order in which I take jobs would earn me more, I accept the system's arrangement. |
| G27 | G / delegation / 1 | — | When teammates finish a joint assignment, I still want to decide which version is submitted. |
| G28 | G / delegation / -1 | — | When I leave subletting my room to an agent, I do not intervene in tenant selection as long as the rent meets my expectation. |
| G29 | G / allocation / 1 | 17 | When a limited budget forces cuts, I most want to preserve my authority to decide what gets cut. |
| G30 | G / allocation / -1 | 9 | When my team splits a bonus, I first look for an arrangement that lets me come away with a little more. |
| G31 | G / allocation / 1 | — | When my family has only one free time slot left, I would rather rest less and decide how it is used. |
| G32 | G / allocation / -1 | 45 | When spots in a group order are limited, as long as I can buy what I need, I do not care who allocates them. |
| G33 | G / allocation / 1 | — | When shared storage space is insufficient, I would rather use a little less space and decide each person's share. |
| G34 | G / allocation / -1 | — | When a bonus forces a choice between two options, I care more about how much I actually receive than who allocates it. |
| G35 | G / allocation / 1 | — | When public charging spaces are scarce, I am willing to charge for less time if people rotate in the order I set. |
| G36 | G / allocation / -1 | — | When there is limited food at a group meal, I do not mind others deciding the division as long as I get the dishes I want. |
| G37 | G / allocation / 1 | 21 | When the company cuts the number of contract renewals, I would accept a smaller bonus if it meant I could decide who stays. |
| G38 | G / allocation / -1 | — | When tickets must be purchased together, a friend can place the order as long as I can get a suitable seat. |
| G39 | G / allocation / 1 | — | When resources can support only one proposal, I would rather receive less return and have my proposal win. |
| G40 | G / allocation / -1 | — | When discounted slots are distributed in a group, I do not care who makes the claiming rules as long as I get one. |
| M01 | M / channel / 1 | 2 | When friends discuss where to eat, I narrow it to two choices and say that if they delay any longer, I'll choose. |
| M02 | M / channel / -1 | 14 | When friends discuss where to eat, I shortlist the restaurants first, then offer choices designed to favor my preference. |
| M03 | M / channel / 1 | — | When there is a dispute over a return or exchange, I require it to be handled that day or I will ask the platform to intervene. |
| M04 | M / channel / -1 | — | When I want a neighbor to lower the volume, I first ask other residents to propose shared quiet hours. |
| M05 | M / channel / 1 | — | When a group cannot settle on a plan, I set a vote for tonight and say we will proceed with the current plan if someone is absent. |
| M06 | M / channel / -1 | — | When I want my family to change an arrangement, I first ask the person most likely to agree to help raise it. |
| M07 | M / channel / 1 | — | When a second-hand buyer keeps bargaining down the price, I state my bottom price and say it will no longer be held after the deadline. |
| M08 | M / channel / -1 | — | When a community discussion is divided, I speak privately with several people first, then bring the proposal to the meeting. |
| M09 | M / channel / 1 | — | When a child keeps delaying putting away toys, I make clear that the next activity cannot begin until it is done. |
| M10 | M / channel / -1 | — | When I want to switch to a duty date I prefer, I first assemble several swap options before proposing one. |
| M11 | M / channel / 1 | — | When no one responds in an online collaboration, I name the person responsible and transfer the task if the deadline passes. |
| M12 | M / channel / -1 | 46 | When I want people to support a proposal, I adjust the order of presentation so the most appealing part appears first. |
| M13 | M / channel / 1 | — | When a teammate backs out at the last minute, I clearly state which loss they must bear if they withdraw. |
| M14 | M / channel / -1 | — | When I ask a stranger to swap seats, I present my arrangement as the default first, then ask them to amend it. |
| M15 | M / channel / 1 | 30 | When the other person keeps avoiding a decision, I say the opportunity expires tonight. |
| M16 | M / channel / -1 | — | When I want to move a family gathering, I first ask an influential relative to suggest the date I chose. |
| M17 | M / leverage / 1 | 6 | When I allocate equipment, I make clear that anyone who fails to finish on schedule will temporarily lose access to it. |
| M18 | M / leverage / -1 | — | When I control an event budget, I bundle it into several options that steer people toward the one I prefer. |
| M19 | M / leverage / 1 | 42 | When someone needs me to approve a shift change, I make clear that approval depends on completing the handover. |
| M20 | M / leverage / -1 | — | When I want support from a group administrator, I first provide the information they care about most, then ask them to help move it forward. |
| M21 | M / leverage / 1 | — | When the other party's main income depends on this batch of goods, I state that I will supply it only if they accept the current terms. |
| M22 | M / leverage / -1 | 34 | When a friend knows someone at the venue, I ask them to sound things out first, then choose the proposal most likely to succeed. |
| M23 | M / leverage / 1 | — | When I control the schedule, I state directly that anyone who does not confirm on time will be assigned the default shift. |
| M24 | M / leverage / -1 | 18 | When I know the other party is eager to close, I adjust the order of my offers so the compromise looks more attractive. |
| M25 | M / leverage / 1 | — | When only I know the full process, I require people to follow the steps and stop providing guidance if they do not. |
| M26 | M / leverage / -1 | — | When I want my proposal to gain support first, I place it after the agenda item most likely to pass. |
| M27 | M / leverage / 1 | — | When someone needs to borrow my equipment, I state the return time and the consequences of returning it late. |
| M28 | M / leverage / -1 | — | When I know key members of a group, I first get them to take a position, then make suggestions to the others. |
| M29 | M / resistance / 1 | — | When approval slots are in my hands, I state that I will not hold a slot for anyone who refuses the specified arrangement. |
| M30 | M / resistance / -1 | 10 | When my roommate resists changing the chore schedule, I break the dispute apart and discuss the easiest point of agreement first. |
| M31 | M / resistance / 1 | — | When the other party refuses to cooperate in a renewal, I state that continued refusal will reduce later support. |
| M32 | M / resistance / -1 | — | When I meet opposition, I first adjust the name and presentation of the proposal before discussing it again. |
| M33 | M / resistance / 1 | 38 | When a group member repeatedly goes off topic, I warn them that continuing will lead to limits on their ability to speak. |
| M34 | M / resistance / -1 | — | After a proposal is rejected, I first seek approval for the smallest step, then use the existing investment to advance the rest. |
| M35 | M / resistance / 1 | — | When a roommate will not adjust household chores, I clearly state that non-participants cannot share certain items. |
| M36 | M / resistance / -1 | — | When a customer questions an arrangement, I first ask someone they are more likely to trust to explain it. |
| M37 | M / resistance / 1 | 22 | If someone repeatedly interrupts a meeting, I tell them to stop and ask the moderator to cut them off if they continue. |
| M38 | M / resistance / -1 | 26 | When my family disagrees with a travel plan, I set my preferred itinerary as the default and let them edit it. |
| M39 | M / resistance / 1 | — | When an important partner rejects the terms, I explicitly reduce support until they reconsider. |
| M40 | M / resistance / -1 | — | When an anonymous vote goes against me, I change how the issue is split up so that part of the proposal passes first. |
| H01 | H / closure / 1 | 3 | Even after a teammate makes up for the loss caused by their mistake, I still want them to treat us to a meal and admit defeat. |
| H02 | H / closure / -1 | 15 | Once a teammate has repaired the loss caused by their mistake, I am willing to move on without demanding another gesture from them. |
| H03 | H / closure / 1 | 31 | After the store refunds the overcharge, I still want to leave my negative review up. |
| H04 | H / closure / -1 | — | After a neighbor clears the passage they had occupied, I would rather stop pursuing the matter. |
| H05 | H / closure / 1 | — | After an incorrect call in a competition is corrected, I still want to see the opponent lose the next round. |
| H06 | H / closure / -1 | — | After a mistaken group message is recalled and clarified, I turn my attention back to the task at hand. |
| H07 | H / closure / 1 | — | After false information is clarified, I still want the person who posted it to lose one chance to speak publicly. |
| H08 | H / closure / -1 | — | After the platform restores content deleted by mistake, I stop looking for the person responsible. |
| H09 | H / closure / 1 | — | After the inconvenience caused by a friend's lateness is made up for, I still want them to have to wait next time. |
| H10 | H / closure / -1 | — | After the person who cut the line returns to their place, I think it is enough that order is restored. |
| H11 | H / closure / 1 | — | After the person in charge makes up the missing resources, I still want them to lose one priority opportunity. |
| H12 | H / closure / -1 | — | After the other person fully compensates my loss as agreed, I do not ask for anything extra. |
| H13 | H / closure / 1 | — | After an opponent loses this contest, I still want to see them fail in a selection that does not involve me. |
| H14 | H / closure / -1 | 47 | Once customer service fixes the error, I won't spend more time chasing an individual for accountability. |
| H15 | H / closure / 1 | — | After the opponent has withdrawn, I am still willing to give up one of my own opportunities so that they cannot get it either. |
| H16 | H / closure / -1 | — | After the disputed proposal is withdrawn, I would rather leave the discussion than keep arguing about who won or lost. |
| H17 | H / recognition / 1 | 7 | Even after everyone knows I was right, I still want to hear the other person admit defeat. |
| H18 | H / recognition / -1 | — | After the other person repairs the impact through action, I do not need them to say who was right or wrong. |
| H19 | H / recognition / 1 | — | After a misunderstanding is publicly clarified, I still want the person who first accused me to lose one opportunity to speak. |
| H20 | H / recognition / -1 | 27 | After the anonymous negative review is deleted, I will not keep trying to identify the writer and make them admit they were wrong. |
| H21 | H / recognition / 1 | — | After my manager restores the arrangement, I am still willing to risk an adverse evaluation to make them apologize in person. |
| H22 | H / recognition / -1 | 35 | Once a junior has put the assigned task right, I focus on the result rather than demanding submission. |
| H23 | H / recognition / 1 | — | After everyone has seen the truth, I still want the person involved to admit fault to me in person. |
| H24 | H / recognition / -1 | — | As long as the other person keeps the promise, I do not mind whether they verbally acknowledge the earlier breach. |
| H25 | H / recognition / 1 | 43 | The ruling and compensation are settled, but I still want the other person to lose an opportunity in the next selection. |
| H26 | H / recognition / -1 | — | After the other person completes the ordered compensation, I do not need them to yield to me privately as well. |
| H27 | H / recognition / 1 | — | After a third party has made up the loss, I still want the original person to pay an additional price. |
| H28 | H / recognition / -1 | — | After a third party has made up the loss, I prioritize restoring the arrangement without waiting for the person involved to respond. |
| H29 | H / persistence / 1 | — | After the other person has yielded, I am willing to spend extra effort to make them lose a little more. |
| H30 | H / persistence / -1 | 11 | Once I secure the spot I fought for, I turn my attention to what comes next. |
| H31 | H / persistence / 1 | — | After the disputed outcome is reversed, I still push to make the proposer lose one qualification. |
| H32 | H / persistence / -1 | — | Even when bystanders are still egging things on, I leave once the problem is resolved. |
| H33 | H / persistence / 1 | — | After someone who offended me is no longer working with me, I am still willing to spend time making them lose other opportunities. |
| H34 | H / persistence / -1 | — | After the other person leaves our joint project, I do not carry the old conflict into new settings. |
| H35 | H / persistence / 1 | 23 | The loss has been repaid, but I'm willing to let the relationship freeze for a while if it makes them properly admit defeat. |
| H36 | H / persistence / -1 | — | If continuing to pursue the matter would cost an important collaboration, I resume cooperation once the other person has completed the remedy. |
| H37 | H / persistence / 1 | — | When anonymous pursuit would not affect me, I still want the other person to lose one opportunity after the problem is resolved. |
| H38 | H / persistence / -1 | — | When anonymous pursuit would not affect me, I am willing to stop once the problem is resolved. |
| H39 | H / persistence / 1 | 19 | Even when the other person can affect my career opportunities, I am willing to risk it to make them pay a little more for the past. |
| H40 | H / persistence / -1 | 39 | The weaker party has stopped obstructing me, and I could keep pressing without punishment. I still stop there. |
| N01 | N / justification / 1 | 4 | When rescheduling a gathering at short notice would suit me better, I can simply propose it without first dressing up the reason. |
| N02 | N / justification / -1 | 16 | When rescheduling a gathering at short notice would suit me better, I first find a reason that sounds reasonable to everyone. |
| N03 | N / justification / 1 | — | When a way of dividing the proceeds favors me, I can use it directly without explaining it through an earlier precedent. |
| N04 | N / justification / -1 | — | When a way of dividing the proceeds favors me, I look up a similar earlier division as support. |
| N05 | N / justification / 1 | — | When a group-buying discount is not covered by the rules, I claim it first and decide later how to explain it. |
| N06 | N / justification / -1 | 44 | If a group-buy discount is not clearly covered by the rules, I first look for wording that can justify claiming it. |
| N07 | N / justification / 1 | — | When I know claiming this discount will not bring scrutiny, I do not need to find a general reason for it. |
| N08 | N / justification / -1 | — | When I know claiming this discount will not bring scrutiny, I still want to find a reason that makes sense to me. |
| N09 | N / justification / 1 | — | When a duty roster does not say how to handle a temporary shift swap, I can adjust it directly for this occasion. |
| N10 | N / justification / -1 | — | When a duty roster does not say how to handle a temporary shift swap, I look for an existing clause to support the change. |
| N11 | N / justification / 1 | — | When I want to change an earlier agreement, I can simply say that I prefer to do it my way this time. |
| N12 | N / justification / -1 | — | When I want to change an earlier agreement, I first identify a reason both sides have accepted before. |
| N13 | N / justification / 1 | — | When explaining a purchasing decision, I can state my own trade-off directly without presenting it as customary practice. |
| N14 | N / justification / -1 | — | When explaining a purchasing decision, I choose a reason that connects with the usual way of doing things. |
| N15 | N / justification / 1 | 36 | When no one will scrutinize the shift schedule, I don't need a consistent standard to justify my decision. |
| N16 | N / justification / -1 | — | When no one will scrutinize a shift schedule, I still find a consistent standard to explain my decision. |
| N17 | N / audience / 1 | 8 | When allocating event places in public, I can say directly that this time the choice reflects my own priorities. |
| N18 | N / audience / -1 | — | When allocating event places in public, I connect my arrangement to rules everyone knows. |
| N19 | N / audience / 1 | — | When explaining the original proposal to people who oppose me, I do not need to recast it in reasons they accept. |
| N20 | N / audience / -1 | — | When explaining the original proposal to new members, I draw on rules they know. |
| N21 | N / audience / 1 | — | When anonymously deciding who receives a large grant, I can follow my own priorities without finding a general rationale. |
| N22 | N / audience / -1 | — | When openly deciding who receives a large grant, I make my explanation closely follow the published standards. |
| N23 | N / audience / 1 | — | When a manager might reject my arrangement, I do not rush to invoke their standards on my own behalf. |
| N24 | N / audience / -1 | 28 | If a manager might reject my plan, I first point out how it follows standards they previously set. |
| N25 | N / audience / 1 | 24 | When assigning work to a newcomer who depends on me for tasks, I can say plainly that the arrangement reflects my own judgment and priorities. |
| N26 | N / audience / -1 | — | When assigning work to a newcomer who depends on me, I still look to the team's established rules for a basis. |
| N27 | N / audience / 1 | — | When friends all favor first come, first served, I do not need to use that rule to explain my allocation. |
| N28 | N / audience / -1 | 32 | When my friends agree on first come, first served, I frame my preferred allocation as an extension of that rule. |
| N29 | N / challenge / 1 | — | When a shift schedule is questioned, I can state the arrangement I want to keep without rushing to find a rule for it. |
| N30 | N / challenge / -1 | 12 | When a shift schedule is questioned, I look to the rules to find evidence that supports the arrangement. |
| N31 | N / challenge / 1 | 48 | If I divide the proceeds differently on two occasions, I can explain each tradeoff without forcing both choices into a single rule. |
| N32 | N / challenge / -1 | — | When asked why two divisions of proceeds differ, I look for a basis that can explain both. |
| N33 | N / challenge / 1 | — | When a teammate says changing the date only benefits me, I can admit that without adding another reason. |
| N34 | N / challenge / -1 | — | When a teammate says changing the date only benefits me, I emphasize that the change also accommodates others. |
| N35 | N / challenge / 1 | 40 | Even if sticking to my proposal could cost me a place next time, I would not rush to repackage it in language people prefer to hear. |
| N36 | N / challenge / -1 | — | When keeping my proposal could cost me a place next time, I change to reasons people are more likely to accept. |
| N37 | N / challenge / 1 | — | When an administrator might revoke my permissions, I can still say directly that this is my choice without first citing rules. |
| N38 | N / challenge / -1 | — | When an administrator might revoke my permissions, I first look for parts of the rules that support me. |
| N39 | N / challenge / 1 | — | When no one can trace an anonymous allocation decision back to me, I do not need to add a customary rationale. |
| N40 | N / challenge / -1 | 20 | Even when no one can trace an anonymous allocation decision back to me, I still prepare an explanation grounded in established practice. |
