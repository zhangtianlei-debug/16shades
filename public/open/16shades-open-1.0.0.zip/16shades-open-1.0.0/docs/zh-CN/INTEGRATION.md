# 固定测评接入

本入口支持网站的固定16/48题与中英呈现，两个实现输出相同结构。先看[版本范围](VERSIONS.md)。无需连接现网站接口，也不需要账号、密钥、数据库或外部服务。

## JavaScript

从本包根目录建立自己的脚本，或调整相对导入位置：

```js
import {getForm, scoreFixed} from './integration/fixed.mjs';
const basic = getForm('basic', 'en');
// basic.items 提供固定顺序的 {id,text}，response_options 提供六个选项。
// untouched 初始状态应另用 undefined 或UI状态记录，不能自动提交为3或null。
const answers16 = Array(16).fill(3); // 仅为演示，真实应用须等待用户逐题选择。
const initial = scoreFixed(answers16, 'basic', 'en');
const full = getForm('full', 'en');
const remaining = full.items.slice(16); // 继续32题，保留先前16项。
const answers48 = [...answers16, ...Array(32).fill(3)]; // 人工演示
const updated = scoreFixed(answers48, 'full', 'en');
console.log(updated.result.primary); // 全中立为null，不强配T01。
```

`getForm` 返回独立副本，调用方修改它不改变评分题表。Node示例直接运行；浏览器接入可由自己的构建工具导入模块，或由自己的服务端返回表单与结果。本包未附网页UI，不表示某一浏览器集成已验收。

## Python

```python
from integration.fixed import get_form, score_fixed
form = get_form('full', 'zh-CN')
answers = [3] * 48  # 人工示例，不是默认代答
output = score_fixed(answers, 'full', 'zh-CN')
assert output['result']['primary'] is None
```

两个适配器都接收按固定题序排列的数组，`basic` 恰好16项、`full` 恰好48项；每项为1—5整数或用户明确选择跳过的 `null`（Python为 `None`）。拒绝空洞、缺项、额外项、布尔值、字符串和越界。`3` 是明确中点，`null` 是缺答，两者不等价。语言只接受 `zh-CN` 或 `en`，不静默回退其他语言。

完整结果重新计算全部48题一次，不重复加权基础题，不固定初步类型。保存答案仅用于当前会话衔接；退出、超时与持久化策略由接入方明确实现。示例没有保存真实答案、上传或埋点行为。

## 结果结构与显示

根对象 `schema=16shadows-integration-result-1`。`package_version` 标明适配层版本；`presentation_locale` 与 `presentation_version` 标明实际显示的题面语言；`result.versions.language` 保留原计分母库的 `zh-CN` 身份，不能改成英文后仍复用旧摘要。

| 字段 | 接入方用法 |
|---|---|
| `result.schema` | `prototype-fixed-form-1`，是网站精简输出 |
| `result.bankDigest`、`result.formId`、`result.versions`、`result.stage` | 随结果保存，用于追溯精确表单与版本 |
| `result.axes.G/M/H/N.score` | -1至1的连续分数；不足门槛为null |
| `percent` | 正端整数读数，负端=`100-percent`；不是概率 |
| `direction`、`boundary` | 正/负/未定，以及是否处于边界；不能由取整百分比倒推 |
| `confidence`、`validCount` | 本次方向把握等级与有效题数；等级未经统计校准 |
| `result.primary` | T01—T16或null；精确平分、不足信息不生成唯一类型 |
| `result.candidates` | 全部未排除候选，按ID排列，不是排名 |
| `result.flatResponse` | 至少两项有效回答且全选同档；仅提示 |
| `labels.axes`、`labels.types` | 指定语言的轴端和名称，以ID查找 |
| `heuristic_unvalidated`、`language_equivalence_validated`、`notice` | 保留未经验证标识，并向用户呈现相应说明 |

可用表达：“本次更接近……”“部分方向还没有明显偏向”“这是本次回答的倾向读数”。不得把人物阅读入口、自选角色或推荐结果覆盖成测评主类型。原始Python输出还保留 `pole_means` 等审计字段；见[完整规范](../../standard/C_计分算法规范.md)，不能把网站精简结构宣称为完整研究输出。

## 错误与命令行

适配器抛出含 `code` 的异常；示例将 `{code,message}` 写到标准错误，退出码2，不回显答案。`E_ANSWERS` 答案非法、`E_STAGE` 阶段非法、`E_LOCALE` 语言非法、`E_FILE` 读入失败、`E_CONFIG` 包配置不匹配、`E_USAGE` 命令格式错误。中英错误文本位于 [messages.json](../../integration/messages.json)。未知语言错误以英文返回。

```sh
node examples/node.mjs examples/basic.answers.json basic zh-CN
python3 examples/python.py examples/basic.answers.json basic en
```

命令可从其他目录执行，但脚本路径和输入文件路径须写对。不要将真实答案作为命令行参数、URL或错误日志内容。演示JSON仅含人工构造答案。[答案结构](../../schemas/answers.schema.json) 与 [结果结构](../../schemas/integration-result.schema.json) 描述序列化数据；阶段与题数等关联约束由适配器检查。

## 使用完整参考实现

研究人员可直接使用未改动的Python参考程序，传按题号索引的对象，保留完整诊断输出：

```sh
python3 standard/reference/shadows.py score --bank standard/bank/items.json --form standard/default_form.json --answers standard/verification/example_answers.json --stage full
python3 standard/reference/shadows.py select --bank standard/bank/items.json --seed reference-zh-CN-1
```

原始参考程序只支持其中文self配置，错误消息保留历史中文。新双语固定接入应使用本页适配器。英文160题覆盖层不能直接当成该程序的新bank；随机研究表单也不能交给固定网站适配器。
