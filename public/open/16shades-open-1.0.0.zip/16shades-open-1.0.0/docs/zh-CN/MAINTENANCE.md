# 维护说明

研究或接入使用者只需阅读根 README 并运行验证命令。本包是独立快照：主验证、示例和封装不读取原项目目录、不使用网络，也不上传内容。

编辑源包括 standard 内的历史规范快照、website 内的固定表单和评分源码、data/bank.en.json 的英文覆盖层，以及本包内的接入封装和双语文档。不要只修改生成的题表、示例、期望结果、schema 或评分 JavaScript。

    包内母库 + data/bank.en.json + integration
      -> tools/refresh_derived.py -> examples、docs、schemas
    完整包 + 许可证 + 验收说明
      -> tools/seal.py -> release-manifest.json + ZIP + SHA-256

新版本应从已封装资料包复制，明确记录来源、日期、变更和新版本号；不能覆盖已有正式 ZIP。更新题库、计分或网站快照前，应在项目维护环境中另行核对来源，再将可公开的、无密钥无个人数据无品牌资产的结果带入新包。

从本包根目录运行：

    python3 tools/refresh_derived.py
    python3 verification/verify.py --draft --node /Node绝对路径
    python3 tools/seal.py --output-dir /包外的交付目录
    python3 verification/verify.py --node /Node绝对路径

封包工具拒绝用不同内容覆盖已有 ZIP。生成 ZIP 后，在独立临时目录解压并运行完整验证；将输出保存在 ZIP 旁，不写回包内以免造成清单哈希循环。

许可变更、公开渠道变更或品牌使用范围变更要同步更新根 LICENSE.md、README、CITATION.cff、release-manifest 和本说明，然后重新封包与验证。
