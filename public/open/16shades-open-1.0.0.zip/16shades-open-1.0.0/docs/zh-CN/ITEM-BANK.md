# 题库与英文覆盖层

[中文母库](../../standard/bank/items.json)保留160题的全部原始元数据，[原规范B](../../standard/B_题库设计规范.md)说明设计与字段。每轴40题、正负各20；facet配额16/12/12。4道极端候选及2道固定锚点替代候选不进入当前参考可选范围，实际可选154题；网站使用其中固定48题。

[英文覆盖层](../../data/bank.en.json)按稳定ID逐条关联，完整包含题面、机制、编辑预期依据、混杂风险和次维说明。机器方向、权重、family、excludes、情境、facet与校准状态来自原中文母库。覆盖层记录原始 `source_bank_digest`；自身字节身份由候选清单记录，不作为新计分bank。

网站48题的 `text` 与六个选项逐字沿用已记录发布中的译文。其余112题标记为 `candidate-editorial-translation`，用于阅读和研究准备；未证明语言等值，不能自动生成一个具有独立已验证身份的英文随机量表。[双语题表](QUESTIONS.md)可快速查题，完整元数据以JSON为准。

`expected_discrimination` 是编辑预期，不是实测区分度；`empirical_discrimination` 全部为null。`family` 表示同源情境，`excludes` 约束同表排斥，`facet/contexts` 表示内容覆盖；这些不证明因子结构。仅M39有次维研究提案，本版不计分。

原母库的 `source_documents` 是编写来源记录，不是解压后必需的运行依赖；本包不附带整个产品仓库。英文说明见[Item Bank](../en/ITEM-BANK.md)。
