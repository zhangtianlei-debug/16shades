# 公开发布准备验收 / Public-release preparation acceptance

2026-09-22 · package 1.0.0 · locally sealed; no GitHub upload or website deployment.

| 内容 / Scope | 本包验收 / Acceptance |
|---|---|
| 版本 / Identity | beta-accounts-5 recorded deployment; 1.0.0-draft.1 standard; package 1.0.0 |
| 中文母库 / Chinese bank | 160 original entries and metadata; 48 fixed website items; historical standard bytes preserved |
| 英文资料 / English material | 160 item entries, field correspondence; website48 verbatim; research112 clearly marked |
| 规范 / Specifications | Four axes, 16 names, scoring and sampling rules, metadata, research boundaries, bilingual integration/version/release docs |
| 数值 / Numerical conformance | 24 independent golden cases + 40 synthetic inputs, both locales; JavaScript/Python/deployed-scoring comparison |
| 抽样 / Sampling | 100 seeds, independent quota and replay checks |
| 原参考测试 / Original tests | 16 unit tests |
| 使用路径 / Usability | basic/full × zh-CN/en examples, expected outputs, local document links, error paths |
| 可搬移 / Portability | No original repository path required by main verification; no network/dependency installation |
| 许可 / License | MIT code scope and CC BY 4.0 framework, item bank, documentation and translation scope; brand and artwork excluded |

工程检查和翻译覆盖检查不被表述为心理测量或跨语言验证。主网站未修改或重新部署。最终 ZIP 的独立解压验证输出保存在 ZIP 同级目录，避免把报告写回包内造成清单哈希循环。
