#!/usr/bin/env python3
"""Refresh synthetic examples, readable question tables and JSON schemas from packaged sources."""
import json
import sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'integration'))
from fixed import BANK, FORM, score_fixed, shadows


def write_json(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    example = shadows.load(ROOT/'standard/verification/example_answers.json')
    for stage in ('basic','full'):
        answers = [example[i] for i in FORM['ordered_ids'][:16 if stage=='basic' else 48]]
        write_json(ROOT/'examples'/f'{stage}.answers.json',answers)
        for locale in ('zh-CN','en'):
            write_json(ROOT/'examples'/f'expected.{stage}.{locale}.json',score_fixed(answers,stage,locale))
    en_by = {x['id']:x for x in shadows.load(ROOT/'data/bank.en.json')['items']}
    for locale in ('zh-CN','en'):
        heading = '# 160题与固定表顺序\n\n由包内母库与英文覆盖层生成。数字是网站固定48题的位置；1—16为基础题。—表示本题未在网站使用。元数据和编辑规范见[题库说明](ITEM-BANK.md)。\n\n| ID | 轴 / facet / 方向 | 网站位置 | 题面 |\n|---|---|---:|---|\n' if locale=='zh-CN' else '# All 160 Items and Fixed-Form Order\n\nGenerated from the packaged bank and English overlay. Numbers are positions in the website’s fixed 48; positions 1–16 are basic. — means the item is not in the website form. See [item-bank notes](ITEM-BANK.md) for metadata and editorial rules.\n\n| ID | Axis / facet / direction | Website position | Wording |\n|---|---|---:|---|\n'
        lines = []
        for item in BANK['items']:
            iid = item['id']
            text = item['text'] if locale=='zh-CN' else en_by[iid]['text']
            position = str(FORM['ordered_ids'].index(iid)+1) if iid in FORM['ordered_ids'] else '—'
            lines.append(f"| {iid} | {item['axis']} / {item['facet']} / {item['direction']} | {position} | {text.replace('|','&#124;')} |")
        path = ROOT/'docs'/locale/'QUESTIONS.md'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(heading+'\n'.join(lines)+'\n',encoding='utf-8')
    base = {'$schema':'https://json-schema.org/draft/2020-12/schema'}
    answer = {'type':['integer','null'],'minimum':1,'maximum':5}
    write_json(ROOT/'schemas/answers.schema.json',dict(base,title='Fixed ordered answer array / 固定题序答案数组',
        description='Stage selects exactly 16 or 48 entries; null is an explicit skip, not a default.',
        type='array',items=answer,oneOf=[{'minItems':16,'maxItems':16},{'minItems':48,'maxItems':48}]))
    def obj(properties):
        return {'type':'object','required':list(properties),'additionalProperties':False,'properties':properties}
    enum = lambda values: {'enum':values}
    typ = {'type':'string','pattern':'^T(0[1-9]|1[0-6])$'}
    digest = {'type':'string','pattern':'^[0-9a-f]{64}$'}
    axis = obj({'score':{'type':['number','null'],'minimum':-1,'maximum':1},
                'percent':{'type':['integer','null'],'minimum':0,'maximum':100},
                'direction':enum(['positive','negative',None]),'boundary':{'type':['boolean','null']},
                'confidence':enum(['unavailable','low','moderate','higher']),
                'validCount':{'type':'integer','minimum':0,'maximum':12}})
    versions = obj({k:{'const':v} for k,v in FORM['versions'].items()})
    result = obj({'schema':{'const':'prototype-fixed-form-1'},'versions':versions,
                  'bankDigest':dict(digest,const=FORM['bank_digest']),'formId':dict(digest,const=FORM['form_id']),
                  'stage':enum(['basic','full']),'axes':obj({a:axis for a in 'GMHN'}),
                  'primary':{'anyOf':[typ,{'type':'null'}]},
                  'candidates':{'type':'array','uniqueItems':True,'minItems':1,'maxItems':16,'items':typ},
                  'flatResponse':{'type':'boolean'}})
    labels = obj({'axes':obj({a:obj({'negative':{'type':'string','minLength':1},'positive':{'type':'string','minLength':1}}) for a in 'GMHN'}),
                  'types':obj({f'T{n:02d}':{'type':'string','minLength':1} for n in range(1,17)})})
    envelope = obj({'schema':{'const':'16shadows-integration-result-1'},'package_version':{'const':'1.0.1'},
                    'presentation_locale':enum(['zh-CN','en']),'presentation_version':{'const':'1.0.1'},
                    'language_equivalence_validated':{'const':False},'heuristic_unvalidated':{'const':True},
                    'notice':{'type':'string','minLength':1},'result':result,'labels':labels})
    write_json(ROOT/'schemas/integration-result.schema.json',dict(base,title='Fixed integration result / 固定测评接入结果',**envelope))
    print('Refreshed synthetic examples, bilingual 160-item tables and schemas.')


if __name__=='__main__':
    main()
