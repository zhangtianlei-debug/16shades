# Changelog / 更新记录

## 1.0.1 — 2026-09-23

中文：修正公开资料入口、官网与在线测评链接、GitHub 仓库链接和 GitHub Release 下载路径，并更新包级版本元数据。题库、计分、类型定义和 `standard/` 的 1.0.0-draft.1 历史快照均未改变。

English: Corrected public-material entry points, website and online-assessment links, the GitHub repository link, and the GitHub Release download path; updated package-level version metadata. The item bank, scoring, type definitions, and the `standard/` 1.0.0-draft.1 historical snapshot are unchanged.
