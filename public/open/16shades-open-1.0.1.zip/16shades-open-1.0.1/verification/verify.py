#!/usr/bin/env python3
"""Offline candidate checks. No research data, writes, network or repository required."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import random
import re
import subprocess
import sys
import tempfile
from urllib.parse import unquote

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'integration'))
from fixed import BANK, FORM, WEBSITE, score_fixed, get_form, IntegrationError, shadows


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts
                  and p.name != '.DS_Store')


def verify_integrity():
    manifest = shadows.load(ROOT / 'release-manifest.json')
    require(manifest['status'] == 'public-release-prepared' and manifest['license_decision'] == 'approved_mit_and_cc_by_4_0', 'release state')
    actual_names = {p.relative_to(ROOT).as_posix() for p in files()} - {'release-manifest.json'}
    require(actual_names == set(manifest['files']), 'Unlisted or missing package files')
    for name, entry in manifest['files'].items():
        require(hash_file(ROOT / name) == entry['sha256'] and (ROOT / name).stat().st_size == entry['bytes'], 'Integrity: ' + name)
    return len(actual_names)


def run(cmd, **kw):
    result = subprocess.run(cmd, text=True, capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), **kw)
    require(result.returncode == 0, 'Command failed: ' + ' '.join(cmd) + '\n' + result.stderr)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--node', default='node', help='Node executable, >=22.13.0; tested with 24.19.0')
    parser.add_argument('--draft', action='store_true', help='Maintainer only: skip final package manifest before sealing')
    args = parser.parse_args()
    integrity = None if args.draft else verify_integrity()
    old_manifest = shadows.load(ROOT / 'standard/release_manifest.json')
    snapshot = shadows.load(ROOT / 'standard/presentation_snapshot_manifest.json')
    require(snapshot['presentation_revision'] == '2026-09-14', 'Presentation revision')
    require(snapshot['source_manifest']['sha256_file_bytes'] == hash_file(ROOT / 'standard/release_manifest.json'), 'Original manifest identity')
    for name, info in old_manifest['files'].items():
        actual = hash_file(ROOT / 'standard' / name)
        require(actual == snapshot['files'][name]['sha256_file_bytes'], 'Presentation snapshot mismatch: ' + name)
        if name not in snapshot['changed_presentation_files']:
            require(actual == info['sha256_file_bytes'], 'Immutable standard changed: ' + name)
    for name in snapshot['immutable_contract_files']:
        require(snapshot['files'][name]['sha256_file_bytes'] == old_manifest['files'][name]['sha256_file_bytes'], 'Contract snapshot changed: ' + name)
    require(shadows.digest(BANK) == FORM['bank_digest'] == WEBSITE['bank_digest'], 'Bank digest')
    require(FORM == shadows.select(BANK, 'reference-zh-CN-1'), 'Exact default replay')
    require(FORM['form_id'] == WEBSITE['form_id'] and FORM['versions'] == WEBSITE['versions'], 'Website versions and form')
    require(FORM['ordered_ids'] == [x['id'] for x in WEBSITE['items']], 'Website order')
    by = shadows.items_of(BANK)
    require(len(by) == 160, '160 unique items')
    for item in WEBSITE['items']:
        for field, value in item.items():
            require(by[item['id']][field] == value, 'Snapshot metadata: ' + item['id'] + '.' + field)
    spec = importlib.util.spec_from_file_location('original_release_check', ROOT / 'standard/verification/check_release.py')
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    checker.check_form(FORM, by)
    form_ids = set()
    for n in range(100):
        seed = 'qa-%03d' % n
        form = shadows.select(BANK, seed)
        checker.check_form(form, by)
        require(form == shadows.select(BANK, seed), 'Seed replay: ' + seed)
        form_ids.add(form['form_id'])
    require(len(form_ids) == 100, '100 distinct deterministic forms')
    golden = shadows.load(ROOT / 'standard/verification/golden_cases.json')
    vectors = []
    for case in golden['cases']:
        count = 16 if case['stage'] == 'basic' else 48
        answers = [case['answers'][i] for i in FORM['ordered_ids'][:count]]
        result = score_fixed(answers, case['stage'])['result']
        expected = case['expected']
        require(result['primary'] == expected['primary'] and len(result['candidates']) == expected['candidate_count'], 'Golden type ' + case['id'])
        for axis in shadows.AXES:
            actual = result['axes'][axis]
            target = expected['scores'][axis]
            require(actual['score'] is None if target is None else actual['score'] is not None and math.isclose(actual['score'], target, rel_tol=0, abs_tol=golden['tolerance']), 'Golden score ' + case['id'])
            require(actual['percent'] == expected['percent'][axis], 'Golden percent ' + case['id'])
            for ef, af in [('boundary','boundary'), ('confidence_level','confidence')]:
                if ef in expected:
                    require(actual[af] == expected[ef], 'Golden ' + ef)
        for ef, af in [('candidate_ids','candidates'), ('flat_response','flatResponse')]:
            if ef in expected:
                require(result[af] == expected[ef], 'Golden ' + ef)
        vectors.append({'id': case['id'], 'stage': case['stage'], 'answers': answers})
    rng = random.Random(16048)
    for n in range(40):
        stage = 'basic' if n % 2 else 'full'
        vectors.append({'id':'synthetic-%02d' % n, 'stage':stage,
                        'answers':[rng.choice([None,1,2,3,4,5]) for _ in range(16 if stage == 'basic' else 48)]})
    for vector in vectors:
        vector['expected'] = {locale: score_fixed(vector['answers'], vector['stage'], locale) for locale in ('zh-CN','en')}
    translation = shadows.load(ROOT / 'data/bank.en.json')
    require(translation['source_bank_digest'] == FORM['bank_digest'] and translation['locale'] == 'en', 'English identity')
    en_by = {x['id']:x for x in translation['items']}
    require(len(translation['items']) == len(en_by) == 160 and set(en_by) == set(by), 'English ID coverage')
    for field in ('mechanism','expected_basis'):
        mapping = {}
        for iid, source in by.items():
            mapping.setdefault(source[field], set()).add(en_by[iid][field])
        require(all(len(v)==1 for v in mapping.values()), 'Same source annotation must translate consistently: ' + field)
        require(len({next(iter(v)) for v in mapping.values()}) == len(mapping), 'Distinct annotations collapsed: ' + field)
    require(all(x['text'] not in x['mechanism'] and 'Whether the respondent would endorse' not in x['mechanism'] for x in en_by.values()), 'Mechanism translation must preserve annotation, not duplicate item wording')
    excerpt = shadows.load(ROOT / 'provenance/website-en-excerpt.json')
    presentation_excerpt = shadows.load(ROOT / 'provenance/website-en-excerpt.presentation-2026-09-14.json')
    for iid, item in en_by.items():
        for key in ('text','mechanism','expected_basis'):
            require(isinstance(item[key], str) and item[key].strip() and not re.search('[\u4e00-\u9fff]',item[key]), 'English ' + iid + '.' + key)
        require(len(item['confound_risks']) == len(by[iid]['confound_risks']), 'Risk annotation count ' + iid)
        require(all(isinstance(x,str) and x.strip() and not re.search('[\u4e00-\u9fff]',x) for x in item['confound_risks']), 'English risks ' + iid)
        require(len(item['secondary']) == len(by[iid]['secondary']), 'Secondary count ' + iid)
        for sec, original in zip(item['secondary'],by[iid]['secondary']):
            require(all(sec[k] == original[k] for k in ('axis','direction','proposed_weight')), 'Secondary identity ' + iid)
        expected_source = 'website-en-snapshot' if iid in FORM['ordered_ids'] else 'candidate-editorial-translation'
        require(item['translation_source'] == expected_source, 'Translation provenance ' + iid)
    for locale in ('zh-CN','en'):
        pres = get_form('full',locale)
        for item, source in zip(pres['items'],WEBSITE['items']):
            require(item['id'] == source['id'], 'Presentation order')
            require(item['text'] == (source['text'] if locale == 'zh-CN' else excerpt[source['text']]), 'Exact presentation text')
            if locale == 'en':
                require(item['text'] == en_by[item['id']]['text'], 'Website English overlay text')
        expected_options = [{'value':x['value'],'label':x['label'] if locale == 'zh-CN' else excerpt[x['label']]} for x in WEBSITE['options']]
        require(pres['response_options'] == expected_options, 'Options')
        if locale == 'en':
            require(translation['response_options'] == expected_options,'English bank options')
        framework = shadows.load(ROOT / 'standard/framework.json')
        require(pres['types'] == {x['id']:x['display_alias_zh_CN'] if locale == 'zh-CN' else presentation_excerpt[x['display_alias_zh_CN']] for x in framework['types']}, 'Type names')
    for locale in ('zh-CN','en'):
        require(score_fixed([3.0]*16,'basic',locale) == score_fixed([3]*16,'basic',locale),'JSON numeric integers')
        for invalid in ([], {}, None, [True]*16, ['3']*16, [3.5]*16, [0]*16, [6]*16):
            try:
                score_fixed(invalid,'basic',locale)
            except IntegrationError as error:
                require(error.code == 'E_ANSWERS','Error code')
            else:
                raise AssertionError('Invalid input accepted')
    with tempfile.TemporaryDirectory(prefix='16shadows-verify-') as temp:
        path = Path(temp) / 'vectors.json'
        path.write_text(json.dumps(vectors,ensure_ascii=False),encoding='utf-8')
        node_report = json.loads(run([args.node,str(ROOT / 'verification/check_node.mjs'),str(path)]).stdout)
        # Execute the exact user-facing examples from a different current directory.
        for stage, filename in [('basic','basic.answers.json'),('full','full.answers.json')]:
            for locale in ('zh-CN','en'):
                argfile = str(ROOT / 'examples' / filename)
                js = json.loads(run([args.node,str(ROOT/'examples/node.mjs'),argfile,stage,locale],cwd=temp).stdout)
                py = json.loads(run([sys.executable,str(ROOT/'examples/python.py'),argfile,stage,locale],cwd=temp).stdout)
                require(js == py, 'CLI parity ' + stage + locale)
                expected_path = ROOT / 'examples' / ('expected.' + stage + '.' + locale + '.json')
                require(js == shadows.load(expected_path), 'Published expected example ' + stage + locale)
    unit = run([sys.executable,'-B','-m','unittest','discover','-s',str(ROOT/'standard/reference'),'-p','test_*.py','-v'])
    require('Ran 16 tests' in unit.stderr, 'Original unit-test count')
    # New reader-facing docs must be self-contained. Original archived links retain history.
    checked_links = 0
    for path in list((ROOT/'docs').rglob('*.md')) + list(ROOT.glob('*.md')):
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            target = target.strip('<>').split('#')[0]
            if not target or '://' in target or target.startswith('mailto:'):
                continue
            require((path.parent / unquote(target)).resolve().exists(), 'Broken doc link: ' + str(path.relative_to(ROOT)) + ': ' + target)
            checked_links += 1
    for path in files():
        rel = path.relative_to(ROOT).as_posix()
        require(not path.is_symlink(), 'Symlink excluded')
        require(not re.search(r'(^|/)(\.env|\.git|node_modules|_working)(/|$)|\.(sqlite|db|pem|key|png|webp|svg)$',rel),'Unexpected private/runtime/art file ' + rel)
    report = {'status':'passed','mode':'draft-unsealed' if args.draft else 'sealed',
              'scope':'Engineering conformance and translation completeness; no participant or psychometric validation.',
              'package_version':'1.0.1','website_version':'beta-accounts-5',
              'bank_digest':FORM['bank_digest'],'form_id':FORM['form_id'],
              'bank_items':160,'website_items':48,'translated_research_items':112,
              'golden_cases':len(golden['cases']),'seed_replays':100,'original_unit_tests':16,
              'synthetic_comparison_inputs':len(vectors),'node':node_report,
              'python_invalid_answer_checks':16,'bilingual_cli_pairs':4,
              'local_doc_links_checked':checked_links,'integrity_files':integrity,
              'python_version':sys.version.split()[0], 'network_used':False}
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    try:
        main()
    except (AssertionError, OSError, ValueError, KeyError) as error:
        print(json.dumps({'status':'failed','error':str(error)},ensure_ascii=False),file=sys.stderr)
        sys.exit(1)
