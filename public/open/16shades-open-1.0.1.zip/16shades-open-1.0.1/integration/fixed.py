"""Same fixed-form integration envelope as fixed.mjs, using the original Python scorer."""
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'standard/reference'))
import shadows

MESSAGES = json.loads((ROOT / 'integration/messages.json').read_text(encoding='utf-8'))
BANK = shadows.load(ROOT / 'standard/bank/items.json')
FORM = shadows.load(ROOT / 'standard/default_form.json')
WEBSITE = shadows.load(ROOT / 'website/candidate-form.json')


class IntegrationError(ValueError):
    def __init__(self, code, locale='en'):
        self.code = code
        super().__init__(MESSAGES.get(locale, MESSAGES['en'])[code])


def validate_stage(stage, locale):
    if locale not in ('zh-CN', 'en'):
        raise IntegrationError('E_LOCALE')
    if stage not in ('basic', 'full'):
        raise IntegrationError('E_STAGE', locale)


def get_form(stage='full', locale='zh-CN'):
    validate_stage(stage, locale)
    presentation = shadows.load(ROOT / ('website/locale.' + locale + '.json'))
    if presentation['form_id'] != WEBSITE['form_id'] or presentation['bank_digest'] != WEBSITE['bank_digest']:
        raise IntegrationError('E_CONFIG', locale)
    return dict(presentation, stage=stage, items=presentation['items'][:16 if stage == 'basic' else 48])


def score_fixed(answers, stage='full', locale='zh-CN'):
    validate_stage(stage, locale)
    count = 16 if stage == 'basic' else 48
    if (not isinstance(answers, list) or len(answers) != count or
            any(x is not None and (type(x) not in (int, float) or not 1 <= x <= 5 or not math.isfinite(x) or int(x) != x) for x in answers)):
        raise IntegrationError('E_ANSWERS', locale)
    presentation = get_form(stage, locale)
    by_id = dict(zip(FORM['ordered_ids'][:count], (None if x is None else int(x) for x in answers)))
    try:
        native = shadows.score(BANK, FORM, by_id, stage)
    except shadows.ReferenceError:
        raise IntegrationError('E_CONFIG', locale) from None
    result = {
        'schema': 'prototype-fixed-form-1', 'versions': WEBSITE['versions'],
        'bankDigest': native['bank_digest'], 'formId': native['itemset']['form_id'], 'stage': stage,
        'axes': {a: {'score': x['score'], 'percent': x['percent'], 'direction': x['direction'],
                     'boundary': x['boundary'], 'confidence': x['direction_confidence']['level'],
                     'validCount': x['direction_confidence']['valid_count']} for a, x in native['axes'].items()},
        'primary': native['type']['primary']['id'] if native['type']['primary'] else None,
        'candidates': [x['id'] for x in native['type']['candidates']],
        'flatResponse': native['flat_response'],
    }
    return {
        'schema': '16shadows-integration-result-1', 'package_version': '1.0.1',
        'presentation_locale': locale, 'presentation_version': presentation['version'],
        'language_equivalence_validated': False, 'heuristic_unvalidated': True,
        'notice': MESSAGES[locale]['notice'], 'result': result,
        'labels': {'axes': presentation['axes'], 'types': presentation['types']},
    }
