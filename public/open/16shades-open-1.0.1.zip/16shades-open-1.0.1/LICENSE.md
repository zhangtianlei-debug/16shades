# License scope / 许可范围

Copyright notices for this package use **16 Shades contributors / 16暗影项目**. This identifier is used for attribution; it does not assert a different legal owner.

## MIT

The directories integration, examples, verification, tools, and schemas; the files website/scoring.ts, website/scoring.mjs, and .gitignore; and standard/reference are licensed under the [MIT License](LICENSES/MIT.txt).

代码范围：integration、examples、verification、tools、schemas、website/scoring.ts、website/scoring.mjs、.gitignore 与 standard/reference 均适用 [MIT](LICENSES/MIT.txt)。

## CC BY 4.0

The remainder of the package is licensed under [Creative Commons Attribution 4.0 International](LICENSES/CC-BY-4.0.txt), except files explicitly covered by MIT above. Give appropriate credit to “16 Shades contributors / 16暗影项目”, link the license, and indicate changes.

其余内容范围：除上述 MIT 文件外，本包其余自有分类框架、题库、文档、翻译与资料适用 [CC BY 4.0](LICENSES/CC-BY-4.0.txt)。使用时应注明“16 Shades contributors / 16暗影项目”、链接许可证并说明修改。

The original private-candidate wording retained inside standard is historical source material. It does not narrow the licenses stated here.

## Excluded brand and artwork

Official character artwork, animation, logos, visual brand assets, fonts, collaborations, account services, personal data, credentials, and production-site assets are not included. Character and project names appear only where needed for technical mapping and attribution; this package grants no trademark, endorsement, or visual-brand permission.

## 发布链接 / Release links

Repository: https://github.com/zhangtianlei-debug/16shades-open

Release download: https://github.com/zhangtianlei-debug/16shades-open/releases/download/v1.0.1/16shades-open-1.0.1.zip

Openness notes: https://shades16.com/en/about#openness
