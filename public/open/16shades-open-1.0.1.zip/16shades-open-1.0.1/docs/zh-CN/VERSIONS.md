# 版本与网站对应关系

包版本为 1.0.1，封包日期为 2026-09-23。它修正公开资料入口和链接，不是网站版本升级；本次未重新部署网站。

| 身份 | 本包值 |
|---|---|
| 最近已记录网站发布 | beta-accounts-5，2026-09-10T09:39:43.573Z |
| Framework / Scoring / Item Bank / Reference Test | 均为 1.0.0-draft.1 |
| 新接入封装、双语呈现、英文覆盖层 | 1.0.1 |
| 计分 profile | open-reference-continuous-1 |
| 默认 seed / attempt | reference-zh-CN-1 / 53（从0开始） |

bank_digest = 29f673bb25045920723e0942b7a29afe4c230b1abcd1e33d20abf076ccdaa132

form_id = 71a5db2b7660434320f2749cad338ff8c3bb0a2c1379e5adc4a788e1097cd0c2

评分源码和固定题表已与封包时的当前本地主网站源码逐字比较一致。该比较是本地证据，不代表重新检查线上服务器。

T03 笑面客 / Smiler、T05 收割者 / Harvester、T08 悍客 / Bruiser、T14 定局者 / Decider、T15 裁决者 / Arbiter 均在中英展示资料中一致。历史部署英文摘录使用旧显示名，仍作为历史证据保存，不能被改写成当前线上状态。
