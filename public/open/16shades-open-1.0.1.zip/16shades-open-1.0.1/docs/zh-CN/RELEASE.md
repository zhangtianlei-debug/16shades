# 引用、许可与发布状态

本包为 2026-09-23 封装的公开发布准备版，版本 1.0.1。它已在本地封包并通过离线工程验证；本次版本未部署网站。

[GitHub 仓库](https://github.com/zhangtianlei-debug/16shades-open) 提供开放资料源码。[GitHub Release 下载](https://github.com/zhangtianlei-debug/16shades-open/releases/download/v1.0.1/16shades-open-1.0.1.zip)是本包的发布归档路径。[开放说明](https://shades16.com/about#openness)说明许可与范围；官网不托管 1.0.1 ZIP。

## 引用

> 16 Shades / 16暗影. 《双语开放资料包》. Version 1.0.1, 2026-09-23；规范组件 1.0.0-draft.1；对应网站记录版本 beta-accounts-5。MIT（代码）与 CC BY 4.0（框架、题库、文档和翻译）。

引用研究或接入结果时，也应列出使用的组件、bank digest、form ID、stage、实际呈现语言和呈现版本。CITATION.cff 提供机器可读元数据，不虚构 DOI、公开仓库或已发布记录。

## 许可与范围

代码使用 MIT；自有分类框架、题库、文档及翻译使用 CC BY 4.0。精确目录范围、署名要求与品牌例外以 [LICENSE.md](../../LICENSE.md) 为准。

官方人物图像、动画、标志、品牌视觉、字体、联名素材、账号服务、数据库、真实答案、联系资料和运行密钥都不在本包中，也不因这些许可证获得授权。人物和项目名称只为技术映射与署名出现，不授予商标、背书或视觉品牌使用权。

standard 目录内保留的旧私有候选声明是历史快照，不能覆盖本包根目录的许可范围。

## 证据边界

本包只复现固定测评数值、列明的题面与语言资料；不克隆网站。离线检查证明既定输入下的工程一致性与翻译覆盖，不证明人格类型、心理测量属性或跨语言等值。
