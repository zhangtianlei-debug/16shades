# 16 Shades Framework

**Package:** 1.0.1. **Normative framework component:** 1.0.0-draft.1. These are different identities: the package is the release unit; the component identifies the constructed framework it carries. The source normative text is retained unchanged at [A · Four-Dimension Theory Audit and Framework](../../standard/A_四维理论审计与框架.md).

## Status and scope

16 Shades is a constructed, conditional contrast framework for self-reported strategy preferences in the everyday conflict situations covered by a form. It is not a diagnosis, moral score, crime prediction, behavioral probability, intelligence or ability measure, legal or clinical classification, or a claim that four independent factors or sixteen natural personality groups have been demonstrated.

It asks how a respondent says they tend to obtain, advance, close, and justify a choice in a situation. A type is a readable narrative summary of four continuous readings. Ordinary cooperation, boundary-setting, competent oversight, honest explanation, disagreement, or accountability do not by themselves establish a “shadow” strategy. “Shadow” refers to use that disregards others’ interests, enlarges asymmetry, or serves one’s own overreach; the same strategy can be neutral or beneficial in another setting.

## Four predefined contrasts

| ID | Question | Negative pole | Positive pole | Facets | Not measured by the contrast |
|---|---|---|---|---|---|
| G | What is primarily retained when gain and control cannot both be maximized? | **Gain** — concrete resources, time, opportunities, convenience | **Control** — decision rights have value even at some cost | tradeoff, delegation, allocation | ambition, private autonomy, reasonable risk control, formal responsibility |
| M | When another person resists, which path does one mainly rely on to change their choice? | **Strategy** — arrange information, options, relationships, or agenda | **Pressure** — state requirements and costs of acceptance or refusal | channel, leverage, resistance | intelligence, openness versus secrecy, introversion, communication skill, violence |
| H | What makes conflict feel finished after the outside objective is handled? | **Instrumental** — stop when the outside objective is met | **Punitive** — an opponent’s added loss or acknowledgment still has value | closure, recognition, persistence | all accountability, safety action, restitution, reputation repair, willingness to harm instrumentally |
| N | What authorizes a desired choice? | **Justification** — reliance on shared rules, precedent, or jointly acceptable reasons | **Disregard** — one’s own choice can authorize action without shared reasons first | justification, audience, challenge | actual morality, lawfulness, courage, confidence, verbal skill |

The poles are comparative preferences, not mutually exclusive desires. For example, G compares concrete gain with control itself when they trade off; wanting more money because one holds power is not evidence for Control. M is not covert versus public: public agenda design can be Strategy, and a private deadline can be Pressure. H concerns an added cost after remedy, not legitimate repair or prevention. N concerns dependence on shared justification, not whether a person has beliefs or can speak well.

Each axis remains continuous. Scores must never be added into an overall “darkness” total or described as a percentage of someone who is bad.

## Sixteen defined regions

Choose the negative or positive direction on each axis in G–M–H–N order. This produces a defined label region, not an empirically discovered cluster. Exact zero has no leading pole; near-zero scores may retain both candidates. Website English names are authoritative for display.

| ID | Coordinates | Website name |
|---|---|---|
| T01 | Gain · Strategy · Instrumental · Justification | Broker |
| T02 | Gain · Strategy · Instrumental · Disregard | Opportunist |
| T03 | Gain · Strategy · Punitive · Justification | Smiler |
| T04 | Gain · Strategy · Punitive · Disregard | Pursuer |
| T05 | Gain · Pressure · Instrumental · Justification | Harvester |
| T06 | Gain · Pressure · Instrumental · Disregard | Raider |
| T07 | Gain · Pressure · Punitive · Justification | Collector |
| T08 | Gain · Pressure · Punitive · Disregard | Bruiser |
| T09 | Control · Strategy · Instrumental · Justification | Puppet Master |
| T10 | Control · Strategy · Instrumental · Disregard | Agitator |
| T11 | Control · Strategy · Punitive · Justification | Power Broker |
| T12 | Control · Strategy · Punitive · Disregard | Cult Leader |
| T13 | Control · Pressure · Instrumental · Justification | Enforcer |
| T14 | Control · Pressure · Instrumental · Disregard | Decider |
| T15 | Control · Pressure · Punitive · Justification | Arbiter |
| T16 | Control · Pressure · Punitive · Disregard | Tyrant |

Names are not scoring variables and do not entail intelligence, danger, narcissism, occupation, status, or factual conduct. Characters may be expressive; result language must distinguish the response-based strategy reading from character depiction. The implementation data source is `framework.json`; the website English display source is `app/i18n/en.json`.

See [Scoring](SCORING.md), [Sampling](SAMPLING.md), and [Research and validation boundaries](RESEARCH.md).
