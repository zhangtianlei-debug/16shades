# Scoring and Result Contract

**Package:** 1.0.1. **Normative scoring component:** 1.0.0-draft.1; source: [C · Scoring Algorithm Specification](../../standard/C_计分算法规范.md). This is an interpretable rule set, not IRT, a norm, a probability model, or a calibrated confidence interval.

This page describes the full reference contract. The website is behaviorally aligned for the fixed equal-weight form, but emits a reduced presentation object (`prototype-fixed-form-1`). The new adapters wrap that reduced object; see [Integration](INTEGRATION.md) for its fields.

## Inputs and validation

Score a version-identified bank and a replayable 48-item form produced under [Sampling](SAMPLING.md), plus an object mapping item IDs to integer answers `1`–`5` or explicit `null`, and `stage` `basic` or `full`. `basic` uses only the first 16 displayed items (a full answer object is allowed but later items are ignored); `full` requires keys for all 48 positions. A missing key is not neutral and must not silently become `3`.

Reject unknown IDs, duplicate item positions or JSON keys, invalid directions, booleans, non-integers, values outside 1–5, bank/form mismatch, unknown scoring mode, and unsupported versions. An untouched response control is unanswered.

For answer `r`, `z=(r-3)/2`: `1→-1`, `2→-0.5`, `3→0`, `4→0.5`, `5→1`. `z` is agreement with the item, not its axis direction. Direction `d` comes only from item metadata. Current primary weight is `w=1`; compatible rules permit `0.5≤w≤1.5`, but editorial priority does not alter scores.

## Axis formula and display

For valid primary-dimension answers on one axis, separately aggregate the two directions:

```
mu_plus  = sum(w*z for d=+1) / sum(w for d=+1)
mu_minus = sum(w*z for d=-1) / sum(w for d=-1)
S = (mu_plus - mu_minus) / 2     (-1 <= S <= 1)
```

`pole_means` retain both observed means; equal high agreement and equal low agreement can both yield zero and must not be treated as the same psychological state. Facet loss is handled by eligibility and confidence, not hidden reweighting.

The positive-pole display reading is `50 + 50*S`. Round it to an integer with **decimal half-up**; the negative reading is `100 - rounded_positive`. Thus `62.5→63` and the other pole is `37`. Never independently round both sides. Readings are not probability, percentile, composition, accuracy, or prevalence. Type and boundary logic use unrounded `S`.

## Eligibility, zero, boundary, and types

| Stage | Valid primary answers per axis | Per direction | Facets covered |
|---|---:|---:|---:|
| basic | 3 of 4 | 1 | 2 of 3 |
| full | 8 of 12 | 3 | 3 of 3 |

If a threshold fails: `score`, `percent`, `direction`, and `boundary` are `null`; `raw_score` may remain diagnostic but is never a formal display score; confidence is `unavailable`. No automatic replacement or follow-up item is used.

`S>0` selects the positive pole; `S<0` the negative pole; `S=0` selects neither. `|S|<0.10` is a boundary band (exactly `0.10` is outside). A unique `type.primary` requires all four formal scores to be nonzero. Candidate types include every non-excluded combination and are sorted `T01` through `T16`, never by probability; each boundary or undetermined axis doubles candidates. Type number is `1 + 8*bG + 4*bM + 2*bH + bN`, where `b=1` only for a positive pole.

## Diagnostics and unvalidated direction heuristic

For each available same-family 01/02 pair, spaced 12 items apart, calculate `q=d*z` and flag a tension when `abs(q1-q2)>=1.5`. A skipped member makes the pair unevaluated. Tension does not subtract, change, or discard evidence and is not a lie finding. `flat_response=true` requires more than one valid answer and all valid answers selecting the same option. With zero or one valid answer it is false. It is only a flag.

Delete one answered `family` at a time and recompute `S`. `stability` is the fraction of calculable deletions that retain the original direction; post-deletion zero does not retain it. Shared 01/02 family members are deleted together. Original zero, no calculable trial, or impossible calculation yields `null`. It is sensitivity to this item set, not sampling error or retest probability.

Every axis must output `direction_confidence` and `heuristic_unvalidated=true`.

1. Ineligible: `unavailable`.
2. Eligible `basic`: `low`.
3. `full` is `higher` only with `|S|>=0.25`, at least 10 answers, at least 4 per direction, all 3 facets, at least 5 context tags, at least 8 families, `stability>=0.90`, and all required pairs complete with no tension.
4. `full` is `moderate` only with `|S|>=0.10`, `stability>=0.75`, at least 4 context tags, and no discovered tension. Incomplete pairs may reach at most `moderate`.
5. All remaining eligible cases are `low`.

This describes clarity and coverage in this response set; it must never be rendered as “95% confidence” or accuracy.

## Secondary evidence and required output

Secondary annotations do **not** contribute to `S`, answer counts, or confidence in this version: `secondary_scoring_enabled=false`. `secondary_diagnostic` lists answered proposed-secondary IDs only. Enabling them requires a new immutable calibration profile, a maximum proposed item weight of 0.25 of primary (recommended 0.2), at most 10% total secondary evidence per axis, primary-only comparison output, and real-data evaluation; primary eligibility remains primary-only.

The exchangeable result contains no item-level answers, identity data, or character images. Required contract fields are:

| Path | Requirement |
|---|---|
| `schema_version` | `open-reference-score-1` |
| `versions` | exact framework, scoring, item-bank, reference-test, implementation, language, mode, profile, and schema identities |
| `bank_digest`; `itemset.form_id`; `itemset.ordered_ids`; `itemset.stage` | exact scored snapshot and 16/48 included IDs |
| `axes.G/M/H/N` | formal `score`, diagnostic `raw_score`, `pole_means`, display `percent`, `direction`, `boundary`, `direction_confidence`, and `secondary_diagnostic` |
| `type.primary`; `type.candidates` | unique type or `null`; all non-excluded stable-ID candidates |
| `flat_response`; `secondary_scoring_enabled` | response-style flag; always `false` here |

Use exact rational/decimal logic through zero, `0.10`, and half-up decisions; emitted continuous values must agree with the reference implementation within `1e-9`, without converting small nonzero values to zero by tolerance.
