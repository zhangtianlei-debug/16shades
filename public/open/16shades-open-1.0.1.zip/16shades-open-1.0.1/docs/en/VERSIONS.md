# Versions and Website Correspondence

The package is version 1.0.1, sealed on 2026-09-23. It corrects public-material entry points and links. It is not a website-version upgrade, and this version does not redeploy the website.

| Identity | Package value |
|---|---|
| Most recently recorded website deployment | beta-accounts-5, 2026-09-10T09:39:43.573Z |
| Framework / Scoring / Item Bank / Reference Test | All 1.0.0-draft.1 |
| New adapters, bilingual presentation, English overlay | 1.0.1 |
| Scoring profile | open-reference-continuous-1 |
| Default seed / attempt | reference-zh-CN-1 / 53 (zero-based) |

bank_digest = 29f673bb25045920723e0942b7a29afe4c230b1abcd1e33d20abf076ccdaa132

form_id = 71a5db2b7660434320f2749cad338ff8c3bb0a2c1379e5adc4a788e1097cd0c2

The scoring source and fixed form were byte-compared with the current local website sources when the package was prepared. This is local evidence, not a renewed check of the live server.

T03 Smiler, T05 Harvester, T08 Bruiser, T14 Decider, and T15 Arbiter are consistent in the current Chinese and English presentation material. The older English deployment excerpt uses former display aliases and remains historical evidence; it must not be represented as the current online state.
