# 16暗影 · 双语开放资料包

[English](README.en.md) · 包版本 **1.0.1** · 2026-09-23

这是一份可独立阅读、运行和验证的资料包，包含分类框架、160题母库及英文资料、固定48题表单、中英接入示例、版本证据与工程验证。包内固定测评契约保留为 `beta-accounts-5` 中 `/prototype` 与 `/en/prototype` 的历史来源快照。旧 `/quiz`、网站账号、报告叙事、推荐角色、插画和分享功能不属于本包复现范围。

## 官网与开放资料

- [16暗影官网与在线测评](https://shades16.com/prototype)
- [开放说明](https://shades16.com/about#openness)
- [GitHub 仓库](https://github.com/zhangtianlei-debug/16shades-open)
- [GitHub Release 下载：16shades-open-1.0.1.zip](https://github.com/zhangtianlei-debug/16shades-open/releases/download/v1.0.1/16shades-open-1.0.1.zip)

自有代码按 [MIT](LICENSES/MIT.txt) 许可；自有分类框架、题库、文档及翻译按 [CC BY 4.0](LICENSES/CC-BY-4.0.txt) 许可。精确文件范围、署名和品牌例外见[许可](LICENSE.md)。原规范组件仍为 1.0.0-draft.1；本包版本为 1.0.1，没有改题、改分或更改类型映射。

## 先运行一个例子

需要 Python 3.9+；运行 JavaScript 及完整交叉验证还需要 Node.js 22.13+。本轮实测 Python 3.9.6、Node.js 24.19.0。无第三方依赖，无安装步骤。以下命令在解压后的本包根目录运行：

```sh
python3 examples/python.py examples/full.answers.json full zh-CN
node examples/node.mjs examples/full.answers.json full en
python3 verification/verify.py
```

前两个命令输出同一人工示例的双语结果，数值主体相同；与 `examples/expected.full.zh-CN.json`、`examples/expected.full.en.json` 对照。最后一条成功退出码为0，输出 `status: passed`。如果 Node 不在 PATH：`python3 verification/verify.py --node /你的Node绝对路径`。接入错误退出码2，验证失败退出码1。

## 按用途阅读

| 用途 | 中文入口 | English |
|---|---|---|
| 接入16→48题、读取结果、处理错误 | [接入说明](docs/zh-CN/INTEGRATION.md) | [Integration](docs/en/INTEGRATION.md) |
| 理解四轴与16型 | [原始规范A](standard/A_四维理论审计与框架.md) | [Framework](docs/en/FRAMEWORK.md) |
| 移植计分、缺答、平分、边界与把握等级 | [原始规范C](standard/C_计分算法规范.md) | [Scoring](docs/en/SCORING.md) |
| 研究题库与元数据 | [题库说明](docs/zh-CN/ITEM-BANK.md) | [Item bank](docs/en/ITEM-BANK.md) |
| 一次阅读全部160题 | [中文题表](docs/zh-CN/QUESTIONS.md) | [English questions](docs/en/QUESTIONS.md) |
| 重放随机表单 | [原始规范D](standard/D_随机抽题规则.md) | [Sampling](docs/en/SAMPLING.md) |
| 版本、兼容与当前网站证据 | [版本说明](docs/zh-CN/VERSIONS.md) | [Versions](docs/en/VERSIONS.md) |
| 重复验证与验收范围 | [验证说明](docs/zh-CN/VERIFICATION.md) | [Verification](docs/en/VERIFICATION.md) |
| 研究假设与证据边界 | [研究说明](docs/zh-CN/RESEARCH.md) | [Research](docs/en/RESEARCH.md) |
| 引用、许可与发布状态 | [引用与发布](docs/zh-CN/RELEASE.md) | [Citation, license and release](docs/en/RELEASE.md) |

## 包内结构

- `standard/`：原候选的完整快照，保留原字节、原组件清单、规范A—H、中文160题、Python实现和测试。其历史状态、旧相对来源路径与当时的下一步建议是归档记录；本次运行入口和状态以本README为准。
- `website/`：固定48题、原始评分源码、仅去除类型注解的可运行JavaScript，以及两种语言的题面、选项、轴端和类型名。
- `data/bank.en.json`：160题英文覆盖层。网站48题题面逐字保留；另112题为本次编辑翻译，未做跨语言等值验证。它不是另一个可替换中文摘要的计分母库。
- `integration/`、`examples/`：两种语言实现的同一接入封装、双语错误、人工答案与完整期望输出。
- `provenance/`、`verification/`：经最小化摘录的发布证据、归档评分函数和离线复验。
- `schemas/`：答案与接入结果的JSON结构描述。`release-manifest.json` 逐文件记录字节数和SHA-256。
- tools/：刷新派生资料和生成可复验发布 ZIP 的维护工具；它们不上传内容。使用方法见[维护说明](docs/zh-CN/MAINTENANCE.md)。

工程验证可以证明同一输入按既定规则得出同一结果；不能证明人格类型、跨语言或随机表单的统计等值。原始逐题答案不包含在结果中；示例与验证全部使用人工或随机生成的合成答案。
