# 16 Shades · Bilingual Open Materials

[中文](README.md) · Package **1.0.1** · 2026-09-23

This self-contained package provides the framework, 160-item bank with English material, fixed 48-item form, bilingual integration examples, version evidence, and reproducible engineering checks. Its fixed assessment contract is preserved as a historical-source snapshot from `/prototype` and `/en/prototype` in `beta-accounts-5`. The legacy `/quiz`, website accounts, narrative reports, character recommendations, artwork, and sharing features are outside its reproduction scope.

## Website and Open Materials

- [16 Shades website and online assessment](https://shades16.com/en/prototype)
- [Openness notes](https://shades16.com/en/about#openness)
- [GitHub repository](https://github.com/zhangtianlei-debug/16shades-open)
- [GitHub Release download: 16shades-open-1.0.1.zip](https://github.com/zhangtianlei-debug/16shades-open/releases/download/v1.0.1/16shades-open-1.0.1.zip)

Self-owned code is released under the [MIT License](LICENSES/MIT.txt); the self-owned classification framework, item bank, documentation and translations are released under [CC BY 4.0](LICENSES/CC-BY-4.0.txt). See [LICENSE.md](LICENSE.md) for exact scope, attribution, and brand exceptions. Original components remain 1.0.0-draft.1; this package is 1.0.1. No item, scoring rule, or type mapping has been changed.

## Run an example

Python 3.9+ is required; JavaScript examples and complete cross-runtime verification additionally require Node.js 22.13+. Tested here with Python 3.9.6 and Node.js 24.19.0. No third-party dependencies or installation steps. Run from the extracted package root:

```sh
python3 examples/python.py examples/full.answers.json full zh-CN
node examples/node.mjs examples/full.answers.json full en
python3 verification/verify.py
```

The first two commands return localized versions of the same synthetic example with identical scoring facts. Compare with `examples/expected.full.zh-CN.json` and `examples/expected.full.en.json`. Verification returns `status: passed` and exit code 0. If Node is outside PATH: `python3 verification/verify.py --node /absolute/path/to/node`. Integration errors return code 2; verification failures return code 1.

## Reading routes

| Purpose | English | Chinese |
|---|---|---|
| Integrate 16→48 items, results and errors | [Integration](docs/en/INTEGRATION.md) | [接入](docs/zh-CN/INTEGRATION.md) |
| Understand four axes and sixteen types | [Framework](docs/en/FRAMEWORK.md) | [规范A](standard/A_四维理论审计与框架.md) |
| Port scoring and uncertainty behavior | [Scoring](docs/en/SCORING.md) | [规范C](standard/C_计分算法规范.md) |
| Research bank and metadata | [Item bank](docs/en/ITEM-BANK.md) | [题库](docs/zh-CN/ITEM-BANK.md) |
| Read all 160 items | [Questions](docs/en/QUESTIONS.md) | [题表](docs/zh-CN/QUESTIONS.md) |
| Replay constrained forms | [Sampling](docs/en/SAMPLING.md) | [规范D](standard/D_随机抽题规则.md) |
| Trace versions and website evidence | [Versions](docs/en/VERSIONS.md) | [版本](docs/zh-CN/VERSIONS.md) |
| Repeat verification | [Verification](docs/en/VERIFICATION.md) | [验证](docs/zh-CN/VERIFICATION.md) |
| Understand untested assumptions | [Research](docs/en/RESEARCH.md) | [研究](docs/zh-CN/RESEARCH.md) |
| Citation, license and release status | [Citation, license and release](docs/en/RELEASE.md) | [引用、许可与发布](docs/zh-CN/RELEASE.md) |

## Contents

- `standard/`: byte-preserved original proposal, manifest, specifications A–H, Chinese bank, Python reference and tests. Historical status, original repository-relative provenance paths, and old next-step suggestions remain archival statements; this README defines the current status and execution entry points.
- `website/`: fixed form, original TypeScript scoring, executable JavaScript with type annotations removed, and both presentation locales for questions, options, poles and type names.
- `data/bank.en.json`: complete English overlay. The website’s 48 item texts are unchanged; the remaining 112 are new editorial translations without language-equivalence validation. This is not a replacement scoring bank with a Chinese digest.
- `integration/` and `examples/`: matching Python/JavaScript adapters, bilingual errors, synthetic answers and full expected outputs.
- `provenance/` and `verification/`: minimized deployment evidence, extracted deployed scoring functions, and offline checks.
- `schemas/`: JSON structures for answers and integration results. `release-manifest.json` records file sizes and SHA-256 hashes.
- `tools/`: maintainer tools to refresh derived material and seal the package; see [Maintenance](docs/en/MAINTENANCE.md).

Engineering checks demonstrate repeatable implementation of rules, not empirical personality types or language/form equivalence. Outputs exclude item-level answers. Every example and verification response is synthetic.
